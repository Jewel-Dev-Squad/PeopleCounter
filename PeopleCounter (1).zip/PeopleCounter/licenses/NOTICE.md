# Third-party notices

| Component | Use | License |
|---|---|---|
| EfficientDet-Lite0, 320 px, post-training quantized (`efficientdet_lite0_320.tflite`) | Person detection (Balanced) | Apache License 2.0 — from google-coral/test_data |
| SSD MobileNet V2 COCO, quantized with post-processing (`ssd_mobilenet_v2_300.tflite`) | Person detection (Fast) | Apache License 2.0 — from google-coral/test_data |
| LiteRT (`com.google.ai.edge.litert:litert`) | On-device inference | Apache License 2.0 |
| AndroidX / Jetpack Compose / CameraX | UI and camera | Apache License 2.0 |
| `one_person.jpg` (androidTest only, not shipped in the APK) | Instrumented test image (portrait of Grace Hopper, U.S. Navy photo, public domain), from google-coral/test_data | Public domain |

The full Apache License 2.0 text is in `google-coral-test_data-LICENSE.txt`.
The models were trained on the COCO dataset; class index 0 = "person".
No model, runtime or library used here requires an API key, an account, a subscription or a network connection at runtime.
