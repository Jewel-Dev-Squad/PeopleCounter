# LiteRT / TensorFlow Lite uses JNI; keep its classes if minification is enabled later.
-keep class org.tensorflow.lite.** { *; }
-dontwarn org.tensorflow.lite.**
