package com.hibee.peoplecounter.tracking

import com.hibee.peoplecounter.detection.BoundingBox
import com.hibee.peoplecounter.detection.Detection
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ObjectTrackerTest {

    private fun person(x: Float, y: Float = 0.3f, w: Float = 0.15f, h: Float = 0.4f, score: Float = 0.8f) =
        Detection(BoundingBox(x, y, x + w, y + h), score)

    @Test
    fun stationaryPerson_keepsSameIdAndIsConfirmedAfterMinHits() {
        val tracker = ObjectTracker(TrackerConfig(minHitsToConfirm = 3))
        var snap = emptyList<TrackSnapshot>()
        for (i in 0 until 10) snap = tracker.update(listOf(person(0.4f)), i * 100L)
        assertEquals(1, snap.size)
        assertEquals(1, snap[0].id)
        assertTrue(snap[0].confirmed)
    }

    @Test
    fun trackIsNotConfirmedBeforeMinHits() {
        val tracker = ObjectTracker(TrackerConfig(minHitsToConfirm = 3))
        tracker.update(listOf(person(0.4f)), 0)
        val snap = tracker.update(listOf(person(0.4f)), 100)
        assertFalse(snap.single().confirmed)
    }

    @Test
    fun walkingPerson_keepsSameId() {
        val tracker = ObjectTracker()
        val ids = mutableSetOf<Int>()
        for (i in 0 until 20) {
            val snap = tracker.update(listOf(person(0.05f + i * 0.03f)), i * 100L)
            ids += snap.single().id
        }
        assertEquals(setOf(1), ids)
    }

    @Test
    fun fastMotionAtLowFrameRate_stillMatchedByCenterDistance() {
        // 0.08 jumps on a 0.15-wide box give low IoU; centre-distance fallback must match.
        val tracker = ObjectTracker()
        val ids = mutableSetOf<Int>()
        for (i in 0 until 8) ids += tracker.update(listOf(person(0.05f + i * 0.08f)), i * 400L).single().id
        assertEquals(1, ids.size)
    }

    @Test
    fun twoPeople_getDistinctStableIds() {
        val tracker = ObjectTracker()
        var snap = emptyList<TrackSnapshot>()
        for (i in 0 until 6) snap = tracker.update(listOf(person(0.1f), person(0.6f)), i * 100L)
        assertEquals(2, snap.size)
        assertNotEquals(snap[0].id, snap[1].id)
        // Swap detection order: IDs must follow position, not list order.
        val left = snap.first { it.box.left < 0.5f }.id
        snap = tracker.update(listOf(person(0.6f), person(0.1f)), 700)
        assertEquals(left, snap.first { it.box.left < 0.5f }.id)
    }

    @Test
    fun shortOcclusion_keepsId_longOcclusion_dropsTrack() {
        val tracker = ObjectTracker(TrackerConfig(maxLostMs = 1_000))
        for (i in 0 until 5) tracker.update(listOf(person(0.4f)), i * 100L)
        // Hidden for 600 ms -> still alive and re-matched.
        tracker.update(emptyList(), 700)
        val back = tracker.update(listOf(person(0.4f)), 1_000)
        assertEquals(1, back.single().id)
        // Hidden for > 1000 ms -> removed.
        tracker.update(emptyList(), 1_500)
        val gone = tracker.update(emptyList(), 2_100)
        assertTrue(gone.isEmpty())
        val newcomer = tracker.update(listOf(person(0.4f)), 2_200)
        assertEquals(2, newcomer.single().id)
    }

    @Test
    fun singleFrameFalsePositive_isDroppedWithoutBeingConfirmed() {
        val tracker = ObjectTracker()
        var confirmedCount = 0
        tracker.onTrackConfirmed = { confirmedCount++ }
        tracker.update(listOf(person(0.7f)), 0)
        for (i in 1..10) tracker.update(emptyList(), i * 100L)
        assertEquals(0, confirmedCount)
        assertEquals(0, tracker.activeTrackCount)
    }

    @Test
    fun pauseCompensation_keepsIdsAfterLongPause() {
        val tracker = ObjectTracker(TrackerConfig(maxLostMs = 1_000))
        for (i in 0 until 5) tracker.update(listOf(person(0.4f)), i * 100L)
        tracker.compensatePause(10_000)
        val snap = tracker.update(listOf(person(0.41f)), 10_500)
        assertEquals(1, snap.single().id)
    }

    @Test
    fun reset_restartsIds() {
        val tracker = ObjectTracker()
        tracker.update(listOf(person(0.4f)), 0)
        tracker.reset()
        assertEquals(1, tracker.update(listOf(person(0.4f)), 100).single().id)
    }
}
