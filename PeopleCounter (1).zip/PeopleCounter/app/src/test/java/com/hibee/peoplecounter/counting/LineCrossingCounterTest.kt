package com.hibee.peoplecounter.counting

import com.hibee.peoplecounter.detection.BoundingBox
import com.hibee.peoplecounter.tracking.TrackSnapshot
import org.junit.Assert.assertEquals
import org.junit.Test

class LineCrossingCounterTest {

    private fun track(id: Int, cx: Float, cy: Float, confirmed: Boolean = true, matched: Boolean = true) =
        TrackSnapshot(
            id = id,
            box = BoundingBox(cx - 0.05f, cy - 0.1f, cx + 0.05f, cy + 0.1f),
            score = 0.9f, confirmed = confirmed, matchedThisFrame = matched,
            lastSeenMs = 0, firstSeenMs = 0,
        )

    @Test
    fun jitterInsideDeadBand_doesNotCount() {
        val c = LineCrossingCounter(CountingLine(LineOrientation.HORIZONTAL, 0.5f, 0.05f))
        c.update(listOf(track(1, 0.5f, 0.40f)))
        for (y in listOf(0.48f, 0.53f, 0.47f, 0.54f, 0.49f)) c.update(listOf(track(1, 0.5f, y)))
        assertEquals(0, c.entries)
        assertEquals(0, c.exits)
    }

    @Test
    fun verticalLine_leftToRightIsEntry_invertSwaps() {
        val normal = LineCrossingCounter(CountingLine(LineOrientation.VERTICAL, 0.5f))
        normal.update(listOf(track(1, 0.2f, 0.5f)))
        normal.update(listOf(track(1, 0.8f, 0.5f)))
        assertEquals(1, normal.entries)

        val inverted = LineCrossingCounter(CountingLine(LineOrientation.VERTICAL, 0.5f, invertDirection = true))
        inverted.update(listOf(track(1, 0.2f, 0.5f)))
        inverted.update(listOf(track(1, 0.8f, 0.5f)))
        assertEquals(0, inverted.entries)
        assertEquals(1, inverted.exits)
    }

    @Test
    fun unconfirmedOrUnmatchedTracks_areIgnored() {
        val c = LineCrossingCounter(CountingLine(LineOrientation.VERTICAL, 0.5f))
        c.update(listOf(track(1, 0.2f, 0.5f, confirmed = false)))
        c.update(listOf(track(1, 0.8f, 0.5f, confirmed = false)))
        c.update(listOf(track(2, 0.2f, 0.5f)))
        c.update(listOf(track(2, 0.8f, 0.5f, matched = false)))
        assertEquals(0, c.entries)
    }

    @Test
    fun personAppearingAlreadyPastLine_isNotCounted() {
        val c = LineCrossingCounter(CountingLine(LineOrientation.HORIZONTAL, 0.5f))
        c.update(listOf(track(1, 0.5f, 0.8f)))
        c.update(listOf(track(1, 0.5f, 0.9f)))
        assertEquals(0, c.entries + c.exits)
    }
}
