package com.hibee.peoplecounter.detection

/**
 * Real raw output of efficientdet_lite0_320.tflite for a street photo with four
 * people (one cut off at the left edge) and a bus, captured with the LiteRT
 * Python runtime by tools/make_fixture.py. Box rows are [ymin, xmin, ymax, xmax].
 * Class 5 = bus, class 0 = person (COCO, 0-indexed).
 */
object BusPhotoFixture {
    val BOXES = arrayOf(
        floatArrayOf(0.18639f, 0.00896f, 0.70509f, 0.99104f),
        floatArrayOf(0.36755f, 0.06509f, 0.84097f, 0.28917f),
        floatArrayOf(0.37151f, 0.28137f, 0.79080f, 0.43787f),
        floatArrayOf(0.34722f, 0.83619f, 0.81509f, 1.00151f),
        floatArrayOf(0.53890f, 0.00144f, 0.81110f, 0.08763f),
        floatArrayOf(0.47179f, 0.85359f, 0.62276f, 0.95836f),
        floatArrayOf(0.22964f, 0.00094f, 0.29810f, 0.04051f),
        floatArrayOf(0.56177f, 0.27932f, 0.65287f, 0.35949f),
        floatArrayOf(0.38267f, 0.85695f, 0.66500f, 0.99305f),
        floatArrayOf(0.45988f, 0.28241f, 0.72888f, 0.37922f),
        floatArrayOf(0.35885f, 0.73126f, 0.42985f, 0.79374f),
        floatArrayOf(0.46099f, 0.01877f, 0.62631f, 0.08162f),
        floatArrayOf(0.51202f, 0.00728f, 0.69990f, 0.08002f),
        floatArrayOf(0.45991f, 0.30078f, 0.65720f, 0.43277f),
        floatArrayOf(0.37687f, 0.31893f, 0.49813f, 0.42562f),
        floatArrayOf(0.26269f, 0.98012f, 0.39719f, 0.99488f),
        floatArrayOf(0.49716f, 0.35025f, 0.66553f, 0.42167f),
        floatArrayOf(0.26461f, 0.94090f, 0.42504f, 0.98899f),
        floatArrayOf(0.36716f, 0.74799f, 0.41210f, 0.78283f),
        floatArrayOf(0.45678f, 0.91194f, 0.62515f, 0.99768f),
        floatArrayOf(0.53121f, 0.85479f, 0.62460f, 0.93117f),
        floatArrayOf(0.25792f, 0.00267f, 0.47938f, 0.06003f),
        floatArrayOf(0.37359f, 0.03680f, 0.46692f, 0.08433f),
        floatArrayOf(0.40584f, 0.51567f, 0.48079f, 0.56320f),
        floatArrayOf(0.40068f, 0.58725f, 0.47706f, 0.64324f),
    )
    val CLASSES = floatArrayOf(5.00000f, 0.00000f, 0.00000f, 0.00000f, 0.00000f, 30.00000f, 12.00000f, 30.00000f, 2.00000f, 30.00000f, 0.00000f, 0.00000f, 0.00000f, 30.00000f, 0.00000f, 0.00000f, 30.00000f, 0.00000f, 0.00000f, 30.00000f, 30.00000f, 5.00000f, 0.00000f, 0.00000f, 0.00000f)
    val SCORES = floatArrayOf(0.80078f, 0.78906f, 0.70703f, 0.64844f, 0.26172f, 0.21094f, 0.19922f, 0.19922f, 0.19922f, 0.19922f, 0.17188f, 0.14844f, 0.14844f, 0.13672f, 0.11719f, 0.10938f, 0.10938f, 0.10156f, 0.10156f, 0.10156f, 0.10156f, 0.09375f, 0.09375f, 0.09375f, 0.09375f)
    const val COUNT = 25
}
