package com.hibee.peoplecounter

import com.hibee.peoplecounter.camera.FrameThrottle
import com.hibee.peoplecounter.camera.PerformanceMonitor
import com.hibee.peoplecounter.coverage.CoverageEvaluator
import com.hibee.peoplecounter.coverage.CoverageLevel
import com.hibee.peoplecounter.coverage.ObservationSource
import com.hibee.peoplecounter.coverage.PhoneCameraSource
import com.hibee.peoplecounter.coverage.ValidatedCoverage
import com.hibee.peoplecounter.detection.BoundingBox
import com.hibee.peoplecounter.ui.components.OverlayTransform
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MiscLogicTest {

    private fun source(range: Float, start: Float, end: Float) = object : ObservationSource {
        override val id = "s$start"
        override val displayName = "test"
        override val validatedCoverage = ValidatedCoverage(range, start, end)
    }

    @Test
    fun phoneCameraAlone_isVisibleOnly_withRequiredMessage() {
        val status = CoverageEvaluator.evaluate(100, listOf(PhoneCameraSource))
        assertEquals(CoverageLevel.VISIBLE_ONLY, status.level)
        assertEquals("Counting visible people only. Full 100-meter coverage is unavailable.", status.message)
    }

    @Test
    fun sourcesWithInsufficientRange_doNotCount() {
        val status = CoverageEvaluator.evaluate(100, listOf(source(50f, 0f, 360f)))
        assertEquals(CoverageLevel.VISIBLE_ONLY, status.level)
    }

    @Test
    fun overlappingAndWrappingSectors_areUnionedCorrectly() {
        val partial = CoverageEvaluator.evaluate(100, listOf(source(120f, 0f, 90f), source(120f, 45f, 180f)))
        assertEquals(CoverageLevel.PARTIAL_VALIDATED, partial.level)
        assertEquals(180f, partial.coveredDegrees, 0.01f)

        val wrap = CoverageEvaluator.coveredDegrees(listOf(ValidatedCoverage(100f, 300f, 30f)))
        assertEquals(90f, wrap, 0.01f)

        val full = CoverageEvaluator.evaluate(
            100,
            listOf(source(150f, 0f, 120f), source(150f, 120f, 240f), source(150f, 240f, 360f)),
        )
        assertEquals(CoverageLevel.FULL_VALIDATED, full.level)
    }

    @Test
    fun overlay_fillCenter_cropsWiderImage() {
        // 480x640 image shown in a 1080x1920 view: scale = max(2.25, 3.0) = 3.0,
        // scaled width 1440 -> 180 px cropped on each side.
        val r = OverlayTransform.mapToView(BoundingBox(0f, 0f, 1f, 1f), 480, 640, 1080f, 1920f)
        assertEquals(-180f, r.left, 0.01f)
        assertEquals(1260f, r.right, 0.01f)
        assertEquals(0f, r.top, 0.01f)
        assertEquals(1920f, r.bottom, 0.01f)
        assertEquals(960f, OverlayTransform.mapY(0.5f, 480, 640, 1080f, 1920f), 0.01f)
    }

    @Test
    fun throttle_limitsRate() {
        val t = FrameThrottle(10) // 100 ms
        assertTrue(t.shouldProcess(0))
        assertFalse(t.shouldProcess(50))
        assertTrue(t.shouldProcess(100))
        t.setMaxFramesPerSecond(0) // unlimited
        assertTrue(t.shouldProcess(101))
    }

    @Test
    fun performanceMonitor_flagsSlowDevicesOnlyAfterEnoughSamples() {
        val m = PerformanceMonitor(windowSize = 20, slowThresholdMs = 200, minSamples = 5)
        repeat(4) { m.record(400, it * 400L) }
        assertFalse(m.stats().isStruggling)
        m.record(400, 1600)
        assertTrue(m.stats().isStruggling)
        assertEquals(2.5f, m.stats().processedFps, 0.01f)
    }
}
