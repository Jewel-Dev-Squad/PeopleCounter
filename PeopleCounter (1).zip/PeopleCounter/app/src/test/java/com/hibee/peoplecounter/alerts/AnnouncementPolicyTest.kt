package com.hibee.peoplecounter.alerts

import com.hibee.peoplecounter.counting.CountingSnapshot
import com.hibee.peoplecounter.counting.GenderCounts
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AnnouncementPolicyTest {

    private fun snap(t: Long, unique: Int, counts: GenderCounts) =
        CountingSnapshot.EMPTY.copy(
            visibleCount = counts.total,
            uniqueTracked = unique,
            timestampMs = t,
            genders = counts,
        )

    private fun unknown(n: Int) = GenderCounts(unknown = n)

    @Test
    fun describe_matchesRequestedPhrasing() {
        assertEquals("3 males and 2 females detected", AnnouncementPolicy.describe(GenderCounts(3, 2, 0)))
        assertEquals("1 male detected", AnnouncementPolicy.describe(GenderCounts(1, 0, 0)))
        assertEquals("1 female detected", AnnouncementPolicy.describe(GenderCounts(0, 1, 0)))
        assertEquals(
            "1 male, 2 females and 1 person of unknown gender detected",
            AnnouncementPolicy.describe(GenderCounts(1, 2, 1)),
        )
        assertEquals("4 people detected", AnnouncementPolicy.describe(unknown(4)))
        assertEquals("1 person detected", AnnouncementPolicy.describe(unknown(1)))
        assertEquals("No people detected", AnnouncementPolicy.describe(GenderCounts.NONE))
    }

    @Test
    fun beep_onceWhenPersonConfirmed_notEveryFrame() {
        val p = AnnouncementPolicy(AlertConfig(voiceEnabled = false))
        assertTrue(p.onSnapshot(snap(0, 0, unknown(0))).isEmpty())
        assertEquals(listOf(AudioEvent.Beep), p.onSnapshot(snap(100, 1, unknown(1))))
        for (i in 2..20) assertTrue(p.onSnapshot(snap(i * 100L, 1, unknown(1))).isEmpty())
        assertEquals(listOf(AudioEvent.Beep), p.onSnapshot(snap(2_200, 2, unknown(2))))
    }

    @Test
    fun beep_isRateLimited() {
        val p = AnnouncementPolicy(AlertConfig(voiceEnabled = false, minBeepIntervalMs = 1_000))
        assertEquals(listOf(AudioEvent.Beep), p.onSnapshot(snap(0, 1, unknown(1))))
        assertTrue(p.onSnapshot(snap(300, 2, unknown(2))).isEmpty())
        assertEquals(listOf(AudioEvent.Beep), p.onSnapshot(snap(1_100, 3, unknown(3))))
    }

    @Test
    fun soundDisabled_noBeep() {
        val p = AnnouncementPolicy(AlertConfig(soundEnabled = false, voiceEnabled = false))
        assertTrue(p.onSnapshot(snap(0, 1, unknown(1))).isEmpty())
    }

    @Test
    fun voice_waitsForStableCounts_thenSpeaksOnce() {
        val p = AnnouncementPolicy(AlertConfig(soundEnabled = false, voiceStableMs = 1_500))
        val spoken = (0..40).flatMap { i -> p.onSnapshot(snap(i * 100L, 5, GenderCounts(3, 2, 0))) }
        assertEquals(listOf(AudioEvent.Speak("3 males and 2 females detected")), spoken)
    }

    @Test
    fun voice_ignoresFlicker() {
        val p = AnnouncementPolicy(AlertConfig(soundEnabled = false, voiceStableMs = 1_500))
        // Count alternates every 500 ms: never stable long enough to be spoken.
        val events = (0..40).flatMap { i -> p.onSnapshot(snap(i * 100L, 2, unknown(1 + (i / 5) % 2))) }
        assertTrue(events.isEmpty())
    }

    @Test
    fun voice_announcesChange_andRespectsMinInterval() {
        val p = AnnouncementPolicy(
            AlertConfig(soundEnabled = false, voiceStableMs = 500, minVoiceIntervalMs = 4_000),
        )
        val events = ArrayList<AudioEvent>()
        var t = 0L
        repeat(10) { events += p.onSnapshot(snap(t, 2, unknown(2))); t += 100 } // spoken at 500
        repeat(10) { events += p.onSnapshot(snap(t, 3, unknown(3))); t += 100 } // stable, but too soon
        assertEquals(listOf(AudioEvent.Speak("2 people detected")), events)
        while (t <= 5_000) { events += p.onSnapshot(snap(t, 3, unknown(3))); t += 100 }
        assertEquals(AudioEvent.Speak("3 people detected"), events.last())
        assertEquals(2, events.size)
    }

    @Test
    fun voice_announcesWhenEveryoneLeft_butNotAtStart() {
        val p = AnnouncementPolicy(AlertConfig(soundEnabled = false, voiceStableMs = 0, minVoiceIntervalMs = 0))
        assertTrue(p.onSnapshot(snap(0, 0, unknown(0))).isEmpty())
        p.onSnapshot(snap(100, 1, unknown(1)))
        assertEquals(listOf(AudioEvent.Speak("1 person detected")), p.onSnapshot(snap(200, 1, unknown(1))))
        p.onSnapshot(snap(300, 1, unknown(0)))
        assertEquals(listOf(AudioEvent.Speak("No people detected")), p.onSnapshot(snap(400, 1, unknown(0))))
    }

    @Test
    fun resetSnapshot_restartsPolicy() {
        val p = AnnouncementPolicy(AlertConfig(voiceEnabled = false))
        p.onSnapshot(snap(0, 4, unknown(4)))
        p.onSnapshot(CountingSnapshot.EMPTY) // Reset button / new session
        assertEquals(listOf(AudioEvent.Beep), p.onSnapshot(snap(5_000, 1, unknown(1))))
    }
}
