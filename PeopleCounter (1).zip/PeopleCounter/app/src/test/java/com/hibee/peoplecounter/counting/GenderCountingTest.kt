package com.hibee.peoplecounter.counting

import com.hibee.peoplecounter.detection.BoundingBox
import com.hibee.peoplecounter.detection.Detection
import com.hibee.peoplecounter.detection.DetectionFrame
import org.junit.Assert.assertEquals
import org.junit.Test

class GenderCountingTest {

    private fun frame(t: Long, vararg centers: Pair<Float, Float>) = DetectionFrame(
        detections = centers.map { (cx, cy) ->
            Detection(BoundingBox(cx - 0.07f, cy - 0.15f, cx + 0.07f, cy + 0.15f), 0.8f)
        },
        frameWidth = 480, frameHeight = 640, inferenceTimeMs = 30, timestampMs = t,
    )

    @Test
    fun tally_needsEnoughAgreeingVotes() {
        val tally = GenderTally(minVotes = 3, minShare = 0.7f)
        tally.record(1, Gender.MALE)
        tally.record(1, Gender.MALE)
        assertEquals(Gender.UNKNOWN, tally.genderOf(1))
        tally.record(1, Gender.MALE)
        assertEquals(Gender.MALE, tally.genderOf(1))
        tally.record(2, Gender.MALE)
        tally.record(2, Gender.FEMALE)
        tally.record(2, Gender.FEMALE)
        assertEquals(Gender.UNKNOWN, tally.genderOf(2)) // 67% < 70%
        repeat(5) { tally.record(2, Gender.FEMALE) }
        assertEquals(Gender.FEMALE, tally.genderOf(2))
        assertEquals(GenderCounts(male = 1, female = 1, unknown = 1), tally.count(listOf(1, 2, 3)))
    }

    @Test
    fun withoutClassifier_everyoneIsUnknown_andCountsUnchanged() {
        val engine = PeopleCountingEngine()
        var s = CountingSnapshot.EMPTY
        for (i in 0 until 20) s = engine.process(frame(i * 100L, 0.2f to 0.5f, 0.5f to 0.5f, 0.8f to 0.5f))
        assertEquals(3, s.visibleCount)
        assertEquals(3, s.uniqueTracked)
        assertEquals(GenderCounts(unknown = 3), s.genders)
    }

    @Test
    fun recordedGenders_appearInSnapshot_andClearOnReset() {
        val engine = PeopleCountingEngine()
        var s = CountingSnapshot.EMPTY
        for (i in 0 until 10) {
            s = engine.process(frame(i * 100L, 0.2f to 0.5f, 0.8f to 0.5f))
            for (t in s.tracks.filter { it.confirmed }) {
                engine.recordGender(t.id, if (t.box.centerX < 0.5f) Gender.MALE else Gender.FEMALE)
            }
        }
        s = engine.process(frame(1_000, 0.2f to 0.5f, 0.8f to 0.5f))
        assertEquals(GenderCounts(male = 1, female = 1), s.genders)
        assertEquals(s.visibleCount, s.genders.total)

        engine.reset()
        for (i in 0 until 5) s = engine.process(frame(2_000 + i * 100L, 0.2f to 0.5f))
        assertEquals(GenderCounts(unknown = 1), s.genders)
    }
}
