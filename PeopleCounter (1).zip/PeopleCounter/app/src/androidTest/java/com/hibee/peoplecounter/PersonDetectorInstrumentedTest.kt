package com.hibee.peoplecounter

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.hibee.peoplecounter.detection.ModelOption
import com.hibee.peoplecounter.detection.TfLitePersonDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Runs the real bundled models on a device/emulator:
 *   ./gradlew connectedDebugAndroidTest
 * one_person.jpg is a public-domain portrait (one person) from google-coral/test_data.
 */
@RunWith(AndroidJUnit4::class)
class PersonDetectorInstrumentedTest {

    private val instrumentation = InstrumentationRegistry.getInstrumentation()

    private fun loadTestImage(size: Int): Bitmap {
        val raw = instrumentation.context.assets.open("one_person.jpg").use { BitmapFactory.decodeStream(it) }
        return Bitmap.createScaledBitmap(raw, size, size, true).copy(Bitmap.Config.ARGB_8888, false)
    }

    @Test
    fun bothModels_loadAndDetectExactlyOnePerson() {
        for (model in ModelOption.entries) {
            TfLitePersonDetector.create(instrumentation.targetContext, model, numThreads = 2).use { detector ->
                val people = detector.detect(loadTestImage(model.inputSize), minScore = 0.5f)
                assertEquals("model=$model", 1, people.size)
                assertTrue(people[0].box.area > 0.3f) // the person fills most of the photo
            }
        }
    }

    @Test
    fun blankImage_detectsNobody() {
        val blank = Bitmap.createBitmap(320, 320, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.GRAY) }
        TfLitePersonDetector.create(instrumentation.targetContext, ModelOption.BALANCED, 2).use { detector ->
            assertTrue(detector.detect(blank, minScore = 0.5f).isEmpty())
        }
    }

    @Test
    fun inferenceTime_isMeasuredNotAssumed() {
        TfLitePersonDetector.create(instrumentation.targetContext, ModelOption.BALANCED, 4).use { detector ->
            val img = loadTestImage(320)
            detector.detect(img, 0.5f) // warm-up
            val runs = 10
            val start = System.nanoTime()
            repeat(runs) { detector.detect(img, 0.5f) }
            val avgMs = (System.nanoTime() - start) / 1e6 / runs
            println("EfficientDet-Lite0 average inference on this device: %.1f ms".format(avgMs))
            assertTrue(avgMs > 0)
        }
    }
}
