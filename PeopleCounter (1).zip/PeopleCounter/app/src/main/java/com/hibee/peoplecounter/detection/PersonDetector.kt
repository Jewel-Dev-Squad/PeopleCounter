package com.hibee.peoplecounter.detection

import android.content.Context
import android.content.res.AssetManager
import android.graphics.Bitmap
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.Closeable
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/** Abstraction so other detectors (e.g. a future GPU or NPU backend) can be swapped in. */
interface PersonDetector : Closeable {
    val model: ModelOption
    val inputSize: Int

    /**
     * @param input ARGB_8888 bitmap of exactly [inputSize] x [inputSize] pixels,
     *              already rotated upright.
     */
    fun detect(input: Bitmap, minScore: Float): List<Detection>
}

/**
 * Runs a bundled COCO detection model with LiteRT on the CPU (XNNPACK).
 * Everything happens on-device; no network access is needed or requested.
 *
 * Not thread-safe: use one instance from a single thread.
 */
class TfLitePersonDetector private constructor(
    override val model: ModelOption,
    private val interpreter: Interpreter,
    private val maxDetections: Int,
) : PersonDetector {

    override val inputSize: Int = model.inputSize

    private val inputBuffer: ByteBuffer =
        ByteBuffer.allocateDirect(inputSize * inputSize * 3).order(ByteOrder.nativeOrder())
    private val pixels = IntArray(inputSize * inputSize)

    // Output order of TFLite_Detection_PostProcess: boxes, classes, scores, count.
    private val outBoxes = Array(1) { Array(maxDetections) { FloatArray(4) } }
    private val outClasses = Array(1) { FloatArray(maxDetections) }
    private val outScores = Array(1) { FloatArray(maxDetections) }
    private val outCount = FloatArray(1)
    private val outputs: Map<Int, Any> = mapOf(0 to outBoxes, 1 to outClasses, 2 to outScores, 3 to outCount)

    private var closed = false

    override fun detect(input: Bitmap, minScore: Float): List<Detection> {
        check(!closed) { "Detector already closed" }
        require(input.width == inputSize && input.height == inputSize) {
            "Expected ${inputSize}x$inputSize input, got ${input.width}x${input.height}"
        }
        input.getPixels(pixels, 0, inputSize, 0, 0, inputSize, inputSize)
        inputBuffer.rewind()
        for (p in pixels) {
            inputBuffer.put(((p shr 16) and 0xFF).toByte())
            inputBuffer.put(((p shr 8) and 0xFF).toByte())
            inputBuffer.put((p and 0xFF).toByte())
        }
        inputBuffer.rewind()

        interpreter.runForMultipleInputsOutputs(arrayOf<Any>(inputBuffer), outputs)

        return DetectionDecoder.decode(
            boxes = outBoxes[0],
            classes = outClasses[0],
            scores = outScores[0],
            count = outCount[0].toInt(),
            personClassId = model.personClassId,
            minScore = minScore,
        )
    }

    override fun close() {
        if (!closed) {
            closed = true
            interpreter.close()
        }
    }

    companion object {
        /**
         * Loads and validates [model]. Throws [IllegalStateException] with a readable
         * message if the asset is missing or its tensors do not match expectations.
         */
        fun create(context: Context, model: ModelOption, numThreads: Int): TfLitePersonDetector {
            val buffer = try {
                loadModel(context.assets, model.assetName)
            } catch (e: Exception) {
                throw IllegalStateException(
                    "Model file '${model.assetName}' not found in app assets. " +
                        "See README → 'AI model' for how to add it.", e,
                )
            }
            val options = Interpreter.Options().apply {
                setNumThreads(numThreads.coerceIn(1, 8))
                setUseXNNPACK(true)
            }
            val interpreter = Interpreter(buffer, options)
            try {
                val input = interpreter.getInputTensor(0)
                val expected = intArrayOf(1, model.inputSize, model.inputSize, 3)
                check(input.shape().contentEquals(expected)) {
                    "Unexpected input shape ${input.shape().contentToString()} for ${model.assetName}"
                }
                check(input.dataType() == DataType.UINT8) {
                    "Unexpected input type ${input.dataType()} for ${model.assetName}"
                }
                check(interpreter.outputTensorCount == 4) {
                    "Expected 4 output tensors (boxes, classes, scores, count), got ${interpreter.outputTensorCount}"
                }
                val boxesShape = interpreter.getOutputTensor(0).shape()
                check(boxesShape.size == 3 && boxesShape[2] == 4) {
                    "Unexpected boxes shape ${boxesShape.contentToString()}"
                }
                return TfLitePersonDetector(model, interpreter, maxDetections = boxesShape[1])
            } catch (e: Exception) {
                interpreter.close()
                throw e
            }
        }

        private fun loadModel(assets: AssetManager, name: String): MappedByteBuffer =
            assets.openFd(name).use { fd ->
                FileInputStream(fd.fileDescriptor).use { stream ->
                    stream.channel.map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
                }
            }
    }
}
