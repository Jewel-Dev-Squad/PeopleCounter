package com.hibee.peoplecounter.camera

import android.content.Context
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.hibee.peoplecounter.settings.AnalysisResolution

/**
 * Binds the rear camera's Preview + ImageAnalysis use cases to a lifecycle.
 * Both use cases use a 4:3 aspect ratio so the analysed frame and the preview
 * show the same field of view, which keeps bounding boxes aligned.
 *
 * Call [unbind] when counting stops so the camera is released immediately.
 */
class CameraController(private val context: Context) {

    private var cameraProvider: ProcessCameraProvider? = null
    private var imageAnalysis: ImageAnalysis? = null
    private var unbound = false

    fun bind(
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView,
        analyzer: FrameAnalyzer,
        resolution: AnalysisResolution,
        onError: (String) -> Unit,
    ) {
        unbound = false
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            if (unbound) return@addListener // stopped before the provider was ready
            try {
                val provider = future.get()
                cameraProvider = provider

                val selector = CameraSelector.DEFAULT_BACK_CAMERA
                if (!provider.hasCamera(selector)) {
                    onError("No rear camera was found on this device.")
                    return@addListener
                }

                val aspect = AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
                val preview = Preview.Builder()
                    .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(aspect).build())
                    .build()
                    .also { it.setSurfaceProvider(previewView.surfaceProvider) }

                val analysisSelector = ResolutionSelector.Builder()
                    .setAspectRatioStrategy(aspect)
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            Size(resolution.width, resolution.height),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER,
                        ),
                    )
                    .build()
                val analysis = ImageAnalysis.Builder()
                    .setResolutionSelector(analysisSelector)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                    .also { it.setAnalyzer(analyzer.executor, analyzer) }
                imageAnalysis = analysis

                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, selector, preview, analysis)
            } catch (e: Exception) {
                Log.e(TAG, "Camera binding failed", e)
                onError("The camera could not be opened: ${e.message ?: e.javaClass.simpleName}")
            }
        }, ContextCompat.getMainExecutor(context))
    }

    /** Stops frame delivery and releases the camera. Main thread only. */
    fun unbind() {
        unbound = true
        imageAnalysis?.clearAnalyzer()
        imageAnalysis = null
        cameraProvider?.unbindAll()
    }

    private companion object {
        const val TAG = "CameraController"
    }
}
