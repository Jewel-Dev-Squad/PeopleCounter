package com.hibee.peoplecounter.detection

import kotlin.math.max
import kotlin.math.min

/**
 * Axis-aligned box in normalized [0, 1] coordinates of the *upright* frame
 * (i.e. after the camera sensor rotation has been applied), so it maps directly
 * onto what the user sees in portrait orientation.
 */
data class BoundingBox(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
) {
    val width: Float get() = (right - left).coerceAtLeast(0f)
    val height: Float get() = (bottom - top).coerceAtLeast(0f)
    val area: Float get() = width * height
    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f

    fun isValid(): Boolean =
        !left.isNaN() && !top.isNaN() && !right.isNaN() && !bottom.isNaN() &&
            right > left && bottom > top

    fun clamped(): BoundingBox = BoundingBox(
        left = left.coerceIn(0f, 1f),
        top = top.coerceIn(0f, 1f),
        right = right.coerceIn(0f, 1f),
        bottom = bottom.coerceIn(0f, 1f),
    )

    fun translated(dx: Float, dy: Float): BoundingBox =
        BoundingBox(left + dx, top + dy, right + dx, bottom + dy)

    /** Intersection-over-union in [0, 1]. Returns 0 for degenerate boxes. */
    fun iou(other: BoundingBox): Float {
        val ix = min(right, other.right) - max(left, other.left)
        val iy = min(bottom, other.bottom) - max(top, other.top)
        if (ix <= 0f || iy <= 0f) return 0f
        val inter = ix * iy
        val union = area + other.area - inter
        return if (union <= 0f) 0f else inter / union
    }

    /** Linear interpolation towards [target]; alpha = 1 returns [target]. */
    fun lerp(target: BoundingBox, alpha: Float): BoundingBox = BoundingBox(
        left + (target.left - left) * alpha,
        top + (target.top - top) * alpha,
        right + (target.right - right) * alpha,
        bottom + (target.bottom - bottom) * alpha,
    )
}

/** A single person detection produced by the model for one frame. */
data class Detection(
    val box: BoundingBox,
    val score: Float,
)

/**
 * All person detections for one analysed frame.
 *
 * @param frameWidth width of the upright frame in pixels (after rotation)
 * @param frameHeight height of the upright frame in pixels (after rotation)
 * @param inferenceTimeMs time spent in pre-processing + model inference + decoding
 * @param timestampMs monotonic timestamp (ms) when the frame was analysed
 */
data class DetectionFrame(
    val detections: List<Detection>,
    val frameWidth: Int,
    val frameHeight: Int,
    val inferenceTimeMs: Long,
    val timestampMs: Long,
)
