package com.hibee.peoplecounter.alerts

import com.hibee.peoplecounter.counting.CountingSnapshot
import com.hibee.peoplecounter.counting.GenderCounts

/** Times are in milliseconds of the snapshot clock, like the tracker's. */
data class AlertConfig(
    val soundEnabled: Boolean = true,
    val voiceEnabled: Boolean = true,
    /** Several people confirmed at once produce one beep, not a burst. */
    val minBeepIntervalMs: Long = 1_000,
    /** The counts must stay unchanged this long before they are spoken. */
    val voiceStableMs: Long = 1_500,
    /** Minimum gap between two spoken announcements. */
    val minVoiceIntervalMs: Long = 4_000,
)

sealed interface AudioEvent {
    data object Beep : AudioEvent
    data class Speak(val text: String) : AudioEvent
}

/**
 * Decides when to play the detection sound and when to speak the counts.
 *
 * - **Beep** when a new person is confirmed by the tracker (`uniqueTracked`
 *   grows). Using confirmed tracks rather than raw boxes means one-frame false
 *   positives and the same person in every frame do not trigger it.
 * - **Speak** the visible counts after they have been stable for
 *   [AlertConfig.voiceStableMs] and differ from what was last said, so the
 *   phone does not talk on every flicker.
 *
 * A drop in `uniqueTracked` (Reset / new session) restarts the policy.
 * Pure Kotlin; unit-tested on the JVM. Call [onSnapshot] from one thread only;
 * [config] may be replaced from any thread.
 */
class AnnouncementPolicy(@Volatile var config: AlertConfig = AlertConfig()) {

    private var lastUniqueTracked = 0
    private var lastBeepMs: Long? = null
    private var candidate: GenderCounts = GenderCounts.NONE
    private var candidateSinceMs = 0L
    private var lastSpoken: GenderCounts = GenderCounts.NONE
    private var lastSpokenMs: Long? = null

    fun onSnapshot(s: CountingSnapshot): List<AudioEvent> {
        if (s.uniqueTracked < lastUniqueTracked) reset()
        val cfg = config
        val now = s.timestampMs
        val events = ArrayList<AudioEvent>(2)

        if (s.uniqueTracked > lastUniqueTracked) {
            lastUniqueTracked = s.uniqueTracked
            if (cfg.soundEnabled && lastBeepMs.let { it == null || now - it >= cfg.minBeepIntervalMs }) {
                lastBeepMs = now
                events += AudioEvent.Beep
            }
        }

        val counts = s.genders
        if (counts != candidate) {
            candidate = counts
            candidateSinceMs = now
        } else if (
            cfg.voiceEnabled &&
            counts != lastSpoken &&
            now - candidateSinceMs >= cfg.voiceStableMs &&
            lastSpokenMs.let { it == null || now - it >= cfg.minVoiceIntervalMs }
        ) {
            lastSpoken = counts
            lastSpokenMs = now
            events += AudioEvent.Speak(describe(counts))
        }
        return events
    }

    fun reset() {
        lastUniqueTracked = 0
        lastBeepMs = null
        candidate = GenderCounts.NONE
        candidateSinceMs = 0L
        lastSpoken = GenderCounts.NONE
        lastSpokenMs = null
    }

    companion object {
        /**
         * "3 males and 2 females detected", "1 male, 1 female and 2 people of unknown
         * gender detected", or just "4 people detected" when nobody has a gender label.
         */
        fun describe(c: GenderCounts): String {
            if (c.total == 0) return "No people detected"
            if (c.male == 0 && c.female == 0) return "${people(c.unknown)} detected"
            val parts = buildList {
                if (c.male > 0) add(if (c.male == 1) "1 male" else "${c.male} males")
                if (c.female > 0) add(if (c.female == 1) "1 female" else "${c.female} females")
                if (c.unknown > 0) add("${people(c.unknown)} of unknown gender")
            }
            val joined = if (parts.size == 1) parts[0]
            else parts.dropLast(1).joinToString(", ") + " and " + parts.last()
            return "$joined detected"
        }

        private fun people(n: Int) = if (n == 1) "1 person" else "$n people"
    }
}
