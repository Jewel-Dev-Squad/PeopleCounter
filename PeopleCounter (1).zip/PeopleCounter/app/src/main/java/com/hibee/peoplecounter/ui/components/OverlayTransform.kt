package com.hibee.peoplecounter.ui.components

import com.hibee.peoplecounter.detection.BoundingBox

/** Rectangle in view pixels. Pure data so the mapping can be unit-tested. */
data class ViewRect(val left: Float, val top: Float, val right: Float, val bottom: Float)

/**
 * Maps normalized boxes from the analysed (upright) image onto the preview view.
 * Matches PreviewView.ScaleType.FILL_CENTER: the image is scaled uniformly until
 * it fills the view and the overflow is cropped equally on both sides.
 */
object OverlayTransform {

    fun mapToView(
        box: BoundingBox,
        imageWidth: Int,
        imageHeight: Int,
        viewWidth: Float,
        viewHeight: Float,
    ): ViewRect {
        if (imageWidth <= 0 || imageHeight <= 0) return ViewRect(0f, 0f, 0f, 0f)
        val scale = maxOf(viewWidth / imageWidth, viewHeight / imageHeight)
        val offsetX = (viewWidth - imageWidth * scale) / 2f
        val offsetY = (viewHeight - imageHeight * scale) / 2f
        return ViewRect(
            left = box.left * imageWidth * scale + offsetX,
            top = box.top * imageHeight * scale + offsetY,
            right = box.right * imageWidth * scale + offsetX,
            bottom = box.bottom * imageHeight * scale + offsetY,
        )
    }

    /** Maps a normalized coordinate on one axis (used for the counting line). */
    fun mapX(x: Float, imageWidth: Int, imageHeight: Int, viewWidth: Float, viewHeight: Float): Float =
        mapToView(BoundingBox(x, 0f, x, 0f), imageWidth, imageHeight, viewWidth, viewHeight).left

    fun mapY(y: Float, imageWidth: Int, imageHeight: Int, viewWidth: Float, viewHeight: Float): Float =
        mapToView(BoundingBox(0f, y, 0f, y), imageWidth, imageHeight, viewWidth, viewHeight).top
}
