package com.hibee.peoplecounter.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hibee.peoplecounter.counting.CountingLine
import com.hibee.peoplecounter.counting.CountingSnapshot
import com.hibee.peoplecounter.counting.LineOrientation
import com.hibee.peoplecounter.ui.theme.CountLine
import com.hibee.peoplecounter.ui.theme.Detected
import com.hibee.peoplecounter.ui.theme.Tentative

/**
 * Draws tracked people on top of the camera preview:
 * solid green = counted (confirmed) person, dashed yellow = not yet confirmed.
 */
@Composable
fun DetectionOverlay(
    snapshot: CountingSnapshot,
    countingLine: CountingLine?,
    showIds: Boolean,
    modifier: Modifier = Modifier,
) {
    val measurer = rememberTextMeasurer()
    val labelStyle = TextStyle(color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)

    Canvas(modifier = modifier) {
        val imgW = snapshot.frameWidth
        val imgH = snapshot.frameHeight
        if (imgW <= 0 || imgH <= 0) return@Canvas
        val strokePx = 3.dp.toPx()

        countingLine?.let { line ->
            val dash = PathEffect.dashPathEffect(floatArrayOf(18f, 12f))
            if (line.orientation == LineOrientation.HORIZONTAL) {
                val y = OverlayTransform.mapY(line.position, imgW, imgH, size.width, size.height)
                drawLine(CountLine, Offset(0f, y), Offset(size.width, y), strokePx, pathEffect = dash)
            } else {
                val x = OverlayTransform.mapX(line.position, imgW, imgH, size.width, size.height)
                drawLine(CountLine, Offset(x, 0f), Offset(x, size.height), strokePx, pathEffect = dash)
            }
        }

        for (track in snapshot.tracks) {
            // Hide tracks that are currently lost (kept only for re-matching).
            if (!track.matchedThisFrame) continue
            val r = OverlayTransform.mapToView(track.box, imgW, imgH, size.width, size.height)
            val color = if (track.confirmed) Detected else Tentative
            drawRect(
                color = color,
                topLeft = Offset(r.left, r.top),
                size = Size(r.right - r.left, r.bottom - r.top),
                style = if (track.confirmed) Stroke(strokePx)
                else Stroke(strokePx * 0.7f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f))),
            )
            if (showIds && track.confirmed) {
                val label = "#${track.id}  ${(track.score * 100).toInt()}%"
                val layout = measurer.measure(label, labelStyle)
                val pad = 4.dp.toPx()
                val top = (r.top - layout.size.height - pad * 2).coerceAtLeast(0f)
                val left = r.left.coerceIn(0f, (size.width - layout.size.width - pad * 2).coerceAtLeast(0f))
                drawRect(
                    color = color,
                    topLeft = Offset(left, top),
                    size = Size(layout.size.width + pad * 2, layout.size.height + pad * 2),
                )
                drawText(layout, topLeft = Offset(left + pad, top + pad))
            }
        }
    }
}
