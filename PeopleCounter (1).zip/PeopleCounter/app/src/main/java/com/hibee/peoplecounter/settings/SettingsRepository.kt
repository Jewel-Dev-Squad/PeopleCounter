package com.hibee.peoplecounter.settings

import android.content.Context
import com.hibee.peoplecounter.counting.LineOrientation
import com.hibee.peoplecounter.detection.ModelOption
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Persists [AppSettings] in private SharedPreferences (excluded from backups). */
class SettingsRepository(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    fun update(transform: (AppSettings) -> AppSettings) {
        val updated = transform(_settings.value)
        _settings.value = updated
        save(updated)
    }

    private fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            model = enumOr(prefs.getString(K_MODEL, null), d.model),
            analysisResolution = enumOr(prefs.getString(K_RES, null), d.analysisResolution),
            maxDetectionsPerSecond = prefs.getInt(K_RATE, d.maxDetectionsPerSecond),
            numThreads = prefs.getInt(K_THREADS, d.numThreads),
            confidenceThreshold = prefs.getFloat(K_CONF, d.confidenceThreshold),
            targetRadiusMeters = prefs.getInt(K_RADIUS, d.targetRadiusMeters),
            showTrackIds = prefs.getBoolean(K_IDS, d.showTrackIds),
            lineCountingEnabled = prefs.getBoolean(K_LINE, d.lineCountingEnabled),
            lineOrientation = enumOr(prefs.getString(K_LINE_OR, null), LineOrientation.HORIZONTAL),
            linePosition = prefs.getFloat(K_LINE_POS, d.linePosition),
            invertLineDirection = prefs.getBoolean(K_LINE_INV, d.invertLineDirection),
            useLocation = prefs.getBoolean(K_LOC, d.useLocation),
            soundAlertEnabled = prefs.getBoolean(K_SOUND, d.soundAlertEnabled),
            voiceAnnouncementsEnabled = prefs.getBoolean(K_VOICE, d.voiceAnnouncementsEnabled),
        )
    }

    private fun save(s: AppSettings) {
        prefs.edit()
            .putString(K_MODEL, s.model.name)
            .putString(K_RES, s.analysisResolution.name)
            .putInt(K_RATE, s.maxDetectionsPerSecond)
            .putInt(K_THREADS, s.numThreads)
            .putFloat(K_CONF, s.confidenceThreshold)
            .putInt(K_RADIUS, s.targetRadiusMeters)
            .putBoolean(K_IDS, s.showTrackIds)
            .putBoolean(K_LINE, s.lineCountingEnabled)
            .putString(K_LINE_OR, s.lineOrientation.name)
            .putFloat(K_LINE_POS, s.linePosition)
            .putBoolean(K_LINE_INV, s.invertLineDirection)
            .putBoolean(K_LOC, s.useLocation)
            .putBoolean(K_SOUND, s.soundAlertEnabled)
            .putBoolean(K_VOICE, s.voiceAnnouncementsEnabled)
            .apply()
    }

    private inline fun <reified E : Enum<E>> enumOr(name: String?, default: E): E =
        name?.let { n -> enumValues<E>().firstOrNull { it.name == n } } ?: default

    private companion object {
        const val K_MODEL = "model"
        const val K_RES = "resolution"
        const val K_RATE = "rate"
        const val K_THREADS = "threads"
        const val K_CONF = "confidence"
        const val K_RADIUS = "radius"
        const val K_IDS = "show_ids"
        const val K_LINE = "line_enabled"
        const val K_LINE_OR = "line_orientation"
        const val K_LINE_POS = "line_position"
        const val K_LINE_INV = "line_invert"
        const val K_LOC = "use_location"
        const val K_SOUND = "sound_alert"
        const val K_VOICE = "voice_announcements"
    }
}
