package com.hibee.peoplecounter.ui

import androidx.camera.view.PreviewView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.hibee.peoplecounter.camera.CameraController
import com.hibee.peoplecounter.camera.FrameAnalyzer
import com.hibee.peoplecounter.settings.AnalysisResolution

/**
 * Live rear-camera preview. The camera is bound while this composable is on
 * screen and unbound (released) as soon as it leaves composition or the
 * resolution changes.
 */
@Composable
fun CameraPreview(
    analyzer: FrameAnalyzer,
    resolution: AnalysisResolution,
    onCameraError: (String) -> Unit,
    onBackground: () -> Unit,
    onForeground: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember {
        PreviewView(context).apply {
            // TextureView-based mode composes reliably with the Compose overlay on top.
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }
    val controller = remember { CameraController(context) }

    DisposableEffect(lifecycleOwner, resolution) {
        controller.bind(lifecycleOwner, previewView, analyzer, resolution, onCameraError)
        onDispose { controller.unbind() }
    }

    // CameraX stops frames when the app goes to the background; mirror that as a
    // pause so tracks are kept and the status is accurate.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> onBackground()
                Lifecycle.Event.ON_START -> onForeground()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    AndroidView(factory = { previewView }, modifier = modifier)
}
