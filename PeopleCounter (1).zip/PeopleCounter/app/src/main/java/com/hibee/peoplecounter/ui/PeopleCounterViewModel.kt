package com.hibee.peoplecounter.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hibee.peoplecounter.camera.FrameAnalyzer
import com.hibee.peoplecounter.camera.PerformanceStats
import com.hibee.peoplecounter.counting.CountingSnapshot
import com.hibee.peoplecounter.coverage.CoverageEvaluator
import com.hibee.peoplecounter.coverage.CoverageStatus
import com.hibee.peoplecounter.coverage.PhoneCameraSource
import com.hibee.peoplecounter.detection.ModelOption
import com.hibee.peoplecounter.location.LocationProvider
import com.hibee.peoplecounter.location.LocationState
import com.hibee.peoplecounter.settings.AppSettings
import com.hibee.peoplecounter.settings.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class DetectionStatus(val label: String) {
    READY("Ready"),
    DETECTING("Detecting"),
    PAUSED("Paused"),
    CAMERA_UNAVAILABLE("Camera Unavailable"),
}

data class UiState(
    val status: DetectionStatus = DetectionStatus.READY,
    /** Extra explanation shown under the status (errors, permission hints …). */
    val statusDetail: String? = null,
    /** True while the camera should be open (Detecting or Paused). */
    val cameraActive: Boolean = false,
    val snapshot: CountingSnapshot = CountingSnapshot.EMPTY,
    val performance: PerformanceStats = PerformanceStats.EMPTY,
    val activeModel: ModelOption? = null,
    val usingFallbackModel: Boolean = false,
    val modelError: String? = null,
    val coverage: CoverageStatus = CoverageEvaluator.evaluate(100, listOf(PhoneCameraSource)),
    val location: LocationState = LocationState.Disabled,
    val cameraPermissionMissing: Boolean = false,
    val permissionPermanentlyDenied: Boolean = false,
    val lastFrameError: String? = null,
)

class PeopleCounterViewModel(app: Application) : AndroidViewModel(app), FrameAnalyzer.Listener {

    val settingsRepository = SettingsRepository(app)
    val settings: StateFlow<AppSettings> = settingsRepository.settings

    private val locationProvider = LocationProvider(app)
    val analyzer = FrameAnalyzer(app.applicationContext, this)

    private val _ui = MutableStateFlow(
        UiState(coverage = CoverageEvaluator.evaluate(settings.value.targetRadiusMeters, listOf(PhoneCameraSource))),
    )
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private var pausedBySettingsScreen = false

    init {
        viewModelScope.launch {
            locationProvider.state.collect { loc -> _ui.update { it.copy(location = loc) } }
        }
        viewModelScope.launch {
            settings.collect { s ->
                _ui.update {
                    it.copy(coverage = CoverageEvaluator.evaluate(s.targetRadiusMeters, listOf(PhoneCameraSource)))
                }
                if (_ui.value.cameraActive) analyzer.configure(s)
            }
        }
    }

    // ---- user actions ----

    /** Call only after the CAMERA permission is granted. */
    fun startCounting() {
        if (_ui.value.cameraActive) return
        // Mark the session active first so listener callbacks from the analysis
        // thread (model loaded, first results) are not discarded as stale.
        _ui.update {
            it.copy(
                status = DetectionStatus.DETECTING,
                statusDetail = null,
                cameraActive = true,
                snapshot = CountingSnapshot.EMPTY,
                cameraPermissionMissing = false,
                permissionPermanentlyDenied = false,
                lastFrameError = null,
            )
        }
        analyzer.resetCounts()
        analyzer.configure(settings.value)
        analyzer.setPaused(false)
        if (settings.value.useLocation) locationProvider.start()
    }

    fun pause() {
        if (_ui.value.status != DetectionStatus.DETECTING) return
        analyzer.setPaused(true)
        _ui.update { it.copy(status = DetectionStatus.PAUSED) }
    }

    fun resume() {
        if (_ui.value.status != DetectionStatus.PAUSED) return
        analyzer.setPaused(false)
        _ui.update { it.copy(status = DetectionStatus.DETECTING) }
    }

    /** Stops counting and releases the camera and the model. The last counts stay visible. */
    fun stop() = endSession(
        status = DetectionStatus.READY,
        detail = "Stopped. Camera and model released. Last counts are shown.",
    )

    fun resetCounts() {
        _ui.update { it.copy(snapshot = CountingSnapshot.EMPTY) }
        analyzer.resetCounts()
    }

    fun onCameraPermissionDenied(permanently: Boolean) {
        _ui.update {
            it.copy(
                status = DetectionStatus.CAMERA_UNAVAILABLE,
                cameraActive = false,
                cameraPermissionMissing = true,
                permissionPermanentlyDenied = permanently,
                statusDetail = if (permanently) {
                    "Camera permission is blocked. Enable it in system Settings → Apps → People Counter → Permissions."
                } else {
                    "Camera permission is needed to see and count people. Images never leave this phone."
                },
            )
        }
    }

    /**
     * Called on every resume: the user may have granted the camera permission or
     * turned on location in system settings while the app was in the background.
     */
    fun onCameraPermissionRechecked(granted: Boolean) {
        locationProvider.refresh()
        if (granted && _ui.value.cameraPermissionMissing) {
            _ui.update {
                it.copy(
                    status = DetectionStatus.READY,
                    statusDetail = "Camera permission granted. Press Start Counting.",
                    cameraPermissionMissing = false,
                    permissionPermanentlyDenied = false,
                )
            }
        }
    }

    fun onCameraError(message: String) = endSession(DetectionStatus.CAMERA_UNAVAILABLE, message)

    /** Single place that releases camera (via cameraActive=false), model, and location. Main thread. */
    private fun endSession(status: DetectionStatus, detail: String) {
        analyzer.setPaused(true)
        analyzer.releaseDetector()
        locationProvider.stop()
        pausedBySettingsScreen = false
        _ui.update {
            it.copy(
                status = status,
                statusDetail = detail,
                cameraActive = false,
                performance = PerformanceStats.EMPTY,
                activeModel = null,
                usingFallbackModel = false,
            )
        }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) = settingsRepository.update(transform)

    fun onLocationPermissionResult(granted: Boolean) {
        if (granted) {
            updateSettings { it.copy(useLocation = true) }
            if (_ui.value.cameraActive) locationProvider.start()
        } else {
            updateSettings { it.copy(useLocation = false) }
        }
    }

    fun setUseLocation(enabled: Boolean) {
        updateSettings { it.copy(useLocation = enabled) }
        if (!enabled) locationProvider.stop()
        else if (_ui.value.cameraActive) locationProvider.start()
    }

    fun hasLocationPermission(): Boolean = locationProvider.hasPermission()

    /**
     * The camera is unbound while Settings/Privacy is open or the app is in the
     * background. Pause so that tracks survive (people still in place keep their
     * IDs) and the status honestly says "Paused"; resume automatically on return.
     */
    fun onLeaveCameraScreen() {
        if (_ui.value.status == DetectionStatus.DETECTING) {
            pause()
            pausedBySettingsScreen = true
        }
    }

    fun onReturnToCameraScreen() {
        if (pausedBySettingsScreen) {
            pausedBySettingsScreen = false
            resume()
        }
    }

    /** Switch to the lighter model after the user accepts the slow-device suggestion. */
    fun switchToFastModel() = updateSettings { it.copy(model = ModelOption.FAST) }

    // ---- FrameAnalyzer.Listener (called on the analysis thread) ----

    override fun onResult(snapshot: CountingSnapshot, stats: PerformanceStats) {
        // Ignore frames that were already queued when the session ended.
        if (!_ui.value.cameraActive) return
        _ui.update { it.copy(snapshot = snapshot, performance = stats, lastFrameError = null) }
    }

    override fun onDetectorState(model: ModelOption?, usedFallback: Boolean, error: String?) {
        if (!_ui.value.cameraActive) return
        _ui.update { it.copy(activeModel = model, usingFallbackModel = usedFallback, modelError = error) }
        if (model == null && error != null) {
            viewModelScope.launch {
                endSession(DetectionStatus.CAMERA_UNAVAILABLE, "Detection model unavailable: $error")
            }
        }
    }

    override fun onFrameError(message: String) {
        _ui.update { it.copy(lastFrameError = message) }
    }

    override fun onCleared() {
        locationProvider.stop()
        analyzer.shutdown()
        super.onCleared()
    }
}
