package com.hibee.peoplecounter.counting

import com.hibee.peoplecounter.detection.DetectionFrame
import com.hibee.peoplecounter.tracking.ObjectTracker
import com.hibee.peoplecounter.tracking.TrackSnapshot
import com.hibee.peoplecounter.tracking.TrackerConfig

/**
 * Result of processing one frame.
 *
 * - [visibleCount]: confirmed people currently in view (the main number). It
 *   includes people missed for at most [EngineConfig.visibleGraceMs] so a single
 *   missed detection does not make the number flicker.
 * - [uniqueTracked]: how many distinct tracks have been confirmed since the last
 *   reset. This is an *estimate* of people who passed through the view: it
 *   over-counts when someone is lost and re-acquired with a new ID and
 *   under-counts people who were never detected for long enough.
 * - [entries] / [exits]: crossings of the optional virtual line.
 */
data class CountingSnapshot(
    val visibleCount: Int,
    val uniqueTracked: Int,
    val entries: Int,
    val exits: Int,
    val tracks: List<TrackSnapshot>,
    val rawDetectionCount: Int,
    val frameWidth: Int,
    val frameHeight: Int,
    val inferenceTimeMs: Long,
    val timestampMs: Long,
) {
    companion object {
        val EMPTY = CountingSnapshot(0, 0, 0, 0, emptyList(), 0, 0, 0, 0, 0)
    }
}

data class EngineConfig(
    val tracker: TrackerConfig = TrackerConfig(),
    val visibleGraceMs: Long = 400,
    /** null disables entry/exit counting. */
    val countingLine: CountingLine? = null,
)

/**
 * Glues detection → tracking → counting together. Not thread-safe: call it from
 * a single thread (the camera analysis thread).
 */
class PeopleCountingEngine(config: EngineConfig = EngineConfig()) {

    private var config = config
    private val tracker = ObjectTracker(config.tracker)
    private val lineCounter = LineCrossingCounter(config.countingLine ?: CountingLine())
    private var uniqueTracked = 0

    init {
        tracker.onTrackConfirmed = { uniqueTracked++ }
        tracker.onTrackRemoved = { lineCounter.forget(it) }
    }

    fun process(frame: DetectionFrame): CountingSnapshot {
        val tracks = tracker.update(frame.detections, frame.timestampMs)
        if (config.countingLine != null) lineCounter.update(tracks)

        val visible = tracks.count {
            it.confirmed && frame.timestampMs - it.lastSeenMs <= config.visibleGraceMs
        }
        return CountingSnapshot(
            visibleCount = visible,
            uniqueTracked = uniqueTracked,
            entries = lineCounter.entries,
            exits = lineCounter.exits,
            tracks = tracks,
            rawDetectionCount = frame.detections.size,
            frameWidth = frame.frameWidth,
            frameHeight = frame.frameHeight,
            inferenceTimeMs = frame.inferenceTimeMs,
            timestampMs = frame.timestampMs,
        )
    }

    fun setCountingLine(line: CountingLine?) {
        config = config.copy(countingLine = line)
        if (line != null) lineCounter.line = line
    }

    /** See [ObjectTracker.compensatePause]. */
    fun onResumedAfterPause(pausedForMs: Long) = tracker.compensatePause(pausedForMs)

    /** Clears all counts and tracks (Reset button). */
    fun reset() {
        tracker.reset()
        lineCounter.reset()
        uniqueTracked = 0
    }
}
