package com.hibee.peoplecounter.counting

/** Gender label for one tracked person. UNKNOWN when no classifier is available or it is unsure. */
enum class Gender { MALE, FEMALE, UNKNOWN }

/**
 * Visible people split by gender. [total] always equals
 * [CountingSnapshot.visibleCount]: everyone without a reliable label is [unknown].
 */
data class GenderCounts(
    val male: Int = 0,
    val female: Int = 0,
    val unknown: Int = 0,
) {
    val total: Int get() = male + female + unknown

    companion object {
        val NONE = GenderCounts()
    }
}

/**
 * Accumulates per-frame gender predictions for each track and turns them into a
 * stable label, so one bad frame does not flip a person's gender.
 *
 * A track gets a label only after [minVotes] predictions, of which at least
 * [minShare] agree. Pure Kotlin; unit-tested on the JVM. Not thread-safe.
 */
class GenderTally(
    private val minVotes: Int = 3,
    private val minShare: Float = 0.7f,
) {
    private val votes = HashMap<Int, IntArray>() // trackId -> [male, female]

    fun record(trackId: Int, gender: Gender) {
        val v = votes.getOrPut(trackId) { IntArray(2) }
        when (gender) {
            Gender.MALE -> v[0]++
            Gender.FEMALE -> v[1]++
            Gender.UNKNOWN -> Unit
        }
    }

    fun genderOf(trackId: Int): Gender {
        val v = votes[trackId] ?: return Gender.UNKNOWN
        val total = v[0] + v[1]
        if (total < minVotes) return Gender.UNKNOWN
        return when {
            v[0] >= total * minShare -> Gender.MALE
            v[1] >= total * minShare -> Gender.FEMALE
            else -> Gender.UNKNOWN
        }
    }

    fun count(trackIds: Iterable<Int>): GenderCounts {
        var male = 0
        var female = 0
        var unknown = 0
        for (id in trackIds) {
            when (genderOf(id)) {
                Gender.MALE -> male++
                Gender.FEMALE -> female++
                Gender.UNKNOWN -> unknown++
            }
        }
        return GenderCounts(male, female, unknown)
    }

    fun forget(trackId: Int) {
        votes.remove(trackId)
    }

    fun reset() = votes.clear()
}
