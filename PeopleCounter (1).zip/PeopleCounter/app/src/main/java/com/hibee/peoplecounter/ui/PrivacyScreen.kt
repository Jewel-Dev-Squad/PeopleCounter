package com.hibee.peoplecounter.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val SECTIONS = listOf(
    "Everything stays on this phone" to
        "Camera frames are analysed in memory by an AI model that runs on this device and are discarded " +
        "immediately. The app does not record video, save photos, or upload anything. It does not even " +
        "request the Internet permission, so it cannot send data anywhere.",
    "Camera permission" to
        "Required to detect people. The camera is opened only after you press Start Counting and is " +
        "released when you press Stop or leave the app.",
    "Location permission (optional)" to
        "Used only to show your own position as the centre of the target radius. It is off by default, " +
        "is never stored or shared, and cannot locate other people – GPS only knows where this phone is.",
    "No identification" to
        "The app detects the shape of a person, not who they are. There is no face recognition. Tracking " +
        "IDs are temporary numbers that are forgotten when counting stops or is reset.",
    "What the 100-meter radius means" to
        "A single phone camera only sees what is in front of it, up to the distance at which people are " +
        "still large enough to detect. It cannot see behind you, through walls or crowds, and it cannot " +
        "measure distance. The app therefore always reports \"visible people only\" and never shows a " +
        "count for the whole radius.",
    "Respect others" to
        "Check local laws and venue rules before counting people, and tell people when counting is taking " +
        "place where that is expected.",
    "Open-source components" to
        "AI models: EfficientDet-Lite0 and SSD MobileNet V2 (COCO), Apache License 2.0, from the " +
        "google-coral/test_data repository. Runtime: LiteRT (TensorFlow Lite), Apache License 2.0. " +
        "UI and camera: Android Jetpack (Compose, CameraX), Apache License 2.0.",
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Privacy & permissions") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            SECTIONS.forEach { (title, body) ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary)
                    Text(body, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
