package com.hibee.peoplecounter.alerts

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

/**
 * Plays the detection beep and speaks announcements with the phone's own
 * text-to-speech engine. Both play on the media stream, so the media volume
 * controls them. No extra permission, library or network access is needed.
 *
 * [beep] and [speak] may be called from any thread. If text-to-speech is not
 * installed or has no voice for the language, [speak] silently does nothing.
 */
class AudioAlerts(context: Context) {

    private val appContext = context.applicationContext
    private val lock = Any()
    private var tone: ToneGenerator? = null
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false

    /** Prepares the beep and starts loading the TTS engine (asynchronous). Idempotent. */
    fun prepare() {
        synchronized(lock) { prepareLocked() }
    }

    private fun prepareLocked() {
        if (tone == null) {
            tone = try {
                ToneGenerator(AudioManager.STREAM_MUSIC, BEEP_VOLUME)
            } catch (e: RuntimeException) {
                Log.w(TAG, "ToneGenerator unavailable", e)
                null
            }
        }
        if (tts == null) {
            var created: TextToSpeech? = null
            created = TextToSpeech(appContext) { status -> onTtsInit(created, status) }
            tts = created
        }
    }

    private fun onTtsInit(engine: TextToSpeech?, status: Int) {
        synchronized(lock) { onTtsInitLocked(engine, status) }
    }

    private fun onTtsInitLocked(engine: TextToSpeech?, status: Int) {
        if (engine == null || engine !== tts) return // released meanwhile
        if (status != TextToSpeech.SUCCESS) {
            Log.w(TAG, "Text-to-speech init failed ($status)")
            return
        }
        val lang = engine.setLanguage(Locale.US)
        ttsReady = lang != TextToSpeech.LANG_MISSING_DATA && lang != TextToSpeech.LANG_NOT_SUPPORTED
        if (!ttsReady) Log.w(TAG, "No English text-to-speech voice installed ($lang)")
    }

    fun beep() {
        synchronized(lock) { tone }?.startTone(ToneGenerator.TONE_PROP_BEEP, BEEP_DURATION_MS)
    }

    /** Replaces anything still being spoken, so announcements never queue up behind stale counts. */
    fun speak(text: String) {
        if (!ttsReady) return
        synchronized(lock) { tts }?.speak(text, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
    }

    fun stopSpeaking() {
        if (ttsReady) synchronized(lock) { tts }?.stop()
    }

    fun release() {
        synchronized(lock) {
            ttsReady = false
            tts?.stop()
            tts?.shutdown()
            tts = null
            tone?.release()
            tone = null
        }
    }

    private companion object {
        const val TAG = "AudioAlerts"
        const val BEEP_VOLUME = 80 // ToneGenerator scale 0..100
        const val BEEP_DURATION_MS = 150
        const val UTTERANCE_ID = "people-count"
    }
}
