package com.hibee.peoplecounter.counting

import com.hibee.peoplecounter.tracking.TrackSnapshot

enum class LineOrientation { HORIZONTAL, VERTICAL }

/**
 * A virtual counting line in normalized upright-frame coordinates.
 *
 * HORIZONTAL line at [position] = y. Moving top → bottom counts as an entry.
 * VERTICAL line at [position] = x. Moving left → right counts as an entry.
 * Set [invertDirection] to swap entry and exit.
 *
 * [hysteresis] is a dead band around the line; a person must move fully past
 * the band to change side, which stops box jitter from producing false counts.
 */
data class CountingLine(
    val orientation: LineOrientation = LineOrientation.HORIZONTAL,
    val position: Float = 0.5f,
    val hysteresis: Float = 0.04f,
    val invertDirection: Boolean = false,
)

/**
 * Counts entries and exits of *confirmed* tracks across a [CountingLine],
 * using the centre of each tracked box. Each side change of a track is one
 * crossing, so a person walking back and forth is counted in and out again.
 */
class LineCrossingCounter(line: CountingLine) {

    private enum class Side { BEFORE, AFTER }

    var line: CountingLine = line
        set(value) {
            field = value
            lastSide.clear() // geometry changed: previous sides are meaningless
        }

    var entries: Int = 0
        private set
    var exits: Int = 0
        private set

    private val lastSide = HashMap<Int, Side>()

    fun update(tracks: List<TrackSnapshot>) {
        for (t in tracks) {
            if (!t.confirmed || !t.matchedThisFrame) continue
            val coordinate = when (line.orientation) {
                LineOrientation.HORIZONTAL -> t.box.centerY
                LineOrientation.VERTICAL -> t.box.centerX
            }
            val side = when {
                coordinate < line.position - line.hysteresis -> Side.BEFORE
                coordinate > line.position + line.hysteresis -> Side.AFTER
                else -> null // inside dead band: keep the previous side
            } ?: continue

            val previous = lastSide.put(t.id, side)
            if (previous != null && previous != side) {
                val forward = previous == Side.BEFORE && side == Side.AFTER
                if (forward xor line.invertDirection) entries++ else exits++
            }
        }
    }

    /** Forget the side of tracks that no longer exist. */
    fun forget(trackId: Int) {
        lastSide.remove(trackId)
    }

    fun reset() {
        entries = 0
        exits = 0
        lastSide.clear()
    }
}
