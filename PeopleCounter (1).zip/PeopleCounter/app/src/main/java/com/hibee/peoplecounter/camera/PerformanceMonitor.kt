package com.hibee.peoplecounter.camera

/**
 * Limits how often frames are sent to the model. CameraX's
 * STRATEGY_KEEP_ONLY_LATEST already prevents a backlog; this additionally caps
 * the rate to save battery when the user chooses a lower detection rate.
 */
class FrameThrottle(maxFramesPerSecond: Int) {
    private var minIntervalMs: Long = intervalFor(maxFramesPerSecond)
    private var lastAcceptedMs: Long? = null

    fun setMaxFramesPerSecond(fps: Int) {
        minIntervalMs = intervalFor(fps)
    }

    fun shouldProcess(nowMs: Long): Boolean {
        val last = lastAcceptedMs
        if (last == null || nowMs - last >= minIntervalMs) {
            lastAcceptedMs = nowMs
            return true
        }
        return false
    }

    fun reset() {
        lastAcceptedMs = null
    }

    private fun intervalFor(fps: Int): Long = if (fps <= 0) 0L else 1000L / fps
}

/** Measured (never assumed) performance numbers shown in the UI. */
data class PerformanceStats(
    val averageInferenceMs: Float,
    val processedFps: Float,
    val samples: Int,
    val isStruggling: Boolean,
) {
    companion object {
        val EMPTY = PerformanceStats(0f, 0f, 0, false)
    }
}

/**
 * Rolling window over the last [windowSize] inferences. Marks the device as
 * "struggling" when the average inference time exceeds [slowThresholdMs]
 * after at least [minSamples] measurements.
 */
class PerformanceMonitor(
    private val windowSize: Int = 30,
    private val slowThresholdMs: Long = 250,
    private val minSamples: Int = 10,
) {
    private val durations = ArrayDeque<Long>()
    private val timestamps = ArrayDeque<Long>()

    fun record(inferenceMs: Long, timestampMs: Long): PerformanceStats {
        durations.addLast(inferenceMs)
        timestamps.addLast(timestampMs)
        while (durations.size > windowSize) durations.removeFirst()
        while (timestamps.size > windowSize) timestamps.removeFirst()
        return stats()
    }

    fun stats(): PerformanceStats {
        if (durations.isEmpty()) return PerformanceStats.EMPTY
        val avg = durations.sum().toFloat() / durations.size
        val span = timestamps.last() - timestamps.first()
        val fps = if (timestamps.size >= 2 && span > 0) (timestamps.size - 1) * 1000f / span else 0f
        return PerformanceStats(
            averageInferenceMs = avg,
            processedFps = fps,
            samples = durations.size,
            isStruggling = durations.size >= minSamples && avg > slowThresholdMs,
        )
    }

    fun reset() {
        durations.clear()
        timestamps.clear()
    }
}
