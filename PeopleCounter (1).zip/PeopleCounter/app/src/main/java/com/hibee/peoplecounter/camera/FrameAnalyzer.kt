package com.hibee.peoplecounter.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.os.SystemClock
import android.util.Log
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.hibee.peoplecounter.counting.CountingSnapshot
import com.hibee.peoplecounter.counting.EngineConfig
import com.hibee.peoplecounter.counting.PeopleCountingEngine
import com.hibee.peoplecounter.detection.DetectionFrame
import com.hibee.peoplecounter.detection.ModelOption
import com.hibee.peoplecounter.detection.PersonDetector
import com.hibee.peoplecounter.detection.TfLitePersonDetector
import com.hibee.peoplecounter.settings.AppSettings
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Camera frame → upright model input → on-device inference → tracking → counts.
 *
 * Threading: every piece of mutable state (detector, engine, bitmaps) is confined
 * to [executor], a single background thread. CameraX delivers frames on the same
 * executor and, with STRATEGY_KEEP_ONLY_LATEST, drops frames while one is being
 * processed, so inference jobs can never pile up. The UI thread is never blocked.
 */
class FrameAnalyzer(
    private val appContext: Context,
    private val listener: Listener,
) : ImageAnalysis.Analyzer {

    interface Listener {
        /** Called on the analysis thread after each processed frame. */
        fun onResult(snapshot: CountingSnapshot, stats: PerformanceStats)

        /** The detector is ready ([model] != null) or could not be loaded ([error] != null). */
        fun onDetectorState(model: ModelOption?, usedFallback: Boolean, error: String?)

        /** A non-fatal problem while processing a frame. */
        fun onFrameError(message: String)
    }

    val executor: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread(r, "people-counter-analysis").apply { priority = Thread.NORM_PRIORITY - 1 }
    }

    // ---- state confined to [executor] ----
    private var detector: PersonDetector? = null
    private var settings: AppSettings = AppSettings()
    private val engine = PeopleCountingEngine(EngineConfig())
    private val throttle = FrameThrottle(settings.maxDetectionsPerSecond)
    private val monitor = PerformanceMonitor()
    private var sourceBitmap: Bitmap? = null
    private var inputBitmap: Bitmap? = null
    private val matrix = Matrix()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val srcRect = Rect()
    private val dstRect = RectF()
    private var consecutiveErrors = 0
    private var pausedAtMs: Long? = null

    @Volatile private var paused = false
    @Volatile private var released = false

    /**
     * (Re)configures the pipeline. Reloads the model only when model or thread
     * count changed. Safe to call from any thread.
     */
    fun configure(newSettings: AppSettings) = post {
        val previous = settings
        settings = newSettings
        throttle.setMaxFramesPerSecond(newSettings.maxDetectionsPerSecond)
        engine.setCountingLine(newSettings.countingLineOrNull())
        val current = detector
        if (current == null || previous.model != newSettings.model || previous.numThreads != newSettings.numThreads) {
            loadDetector(newSettings.model, newSettings.numThreads)
        }
    }

    fun setPaused(value: Boolean) = post {
        if (value == paused) return@post
        paused = value
        val now = SystemClock.elapsedRealtime()
        if (value) {
            pausedAtMs = now
        } else {
            pausedAtMs?.let { engine.onResumedAfterPause(now - it) }
            pausedAtMs = null
            throttle.reset()
        }
    }

    /** Clears counts and tracks (Reset button). */
    fun resetCounts() = post {
        engine.reset()
        monitor.reset()
        listener.onResult(CountingSnapshot.EMPTY, monitor.stats())
    }

    /** Frees the model and buffers but keeps the thread for a later restart. */
    fun releaseDetector() = post {
        detector?.close()
        detector = null
        sourceBitmap?.recycle(); sourceBitmap = null
        inputBitmap?.recycle(); inputBitmap = null
        monitor.reset()
    }

    /**
     * Final shutdown. Queued work (including the model release) still runs on the
     * analysis thread; the caller is not blocked. Cannot be restarted afterwards.
     */
    fun shutdown() {
        released = true
        releaseDetector()
        executor.shutdown()
    }

    override fun analyze(image: ImageProxy) {
        // The ImageProxy must always be closed, otherwise CameraX stops delivering frames.
        try {
            process(image)
        } finally {
            image.close()
        }
    }

    private fun process(proxy: ImageProxy) {
        if (paused || released) return
        val det = detector ?: return // model still loading
        val now = SystemClock.elapsedRealtime()
        if (!throttle.shouldProcess(now)) return
        try {
            val start = SystemClock.elapsedRealtime()
            val rotation = proxy.imageInfo.rotationDegrees
            val source = toBitmap(proxy)
            val input = prepareInput(source, proxy.width, proxy.height, rotation, det.inputSize)
            val detections = det.detect(input, settings.confidenceThreshold)
            val elapsed = SystemClock.elapsedRealtime() - start

            val uprightW = if (rotation % 180 == 0) proxy.width else proxy.height
            val uprightH = if (rotation % 180 == 0) proxy.height else proxy.width
            val snapshot = engine.process(DetectionFrame(detections, uprightW, uprightH, elapsed, now))
            val stats = monitor.record(elapsed, now)
            consecutiveErrors = 0
            listener.onResult(snapshot, stats)
        } catch (t: Throwable) {
            consecutiveErrors++
            Log.e(TAG, "Frame processing failed", t)
            listener.onFrameError(t.message ?: t.javaClass.simpleName)
            if (consecutiveErrors >= 3) {
                // Persistent failure: try the lighter model if there is one.
                consecutiveErrors = 0
                val fallback = det.model.fallback
                if (fallback != null) loadDetector(fallback, settings.numThreads, isFallback = true)
            }
        }
    }

    // ---- helpers (analysis thread only) ----

    private fun loadDetector(model: ModelOption, threads: Int, isFallback: Boolean = false) {
        detector?.close()
        detector = null
        monitor.reset()
        try {
            detector = TfLitePersonDetector.create(appContext, model, threads)
            listener.onDetectorState(model, isFallback, null)
        } catch (t: Throwable) {
            Log.e(TAG, "Could not load ${model.assetName}", t)
            val fallback = model.fallback
            if (fallback != null) {
                loadDetector(fallback, threads, isFallback = true)
            } else {
                listener.onDetectorState(null, isFallback, t.message ?: "Model could not be loaded")
            }
        }
    }

    /** Copies an RGBA_8888 ImageProxy into a reusable bitmap (no per-frame allocation). */
    private fun toBitmap(image: ImageProxy): Bitmap {
        val plane = image.planes[0]
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val buffer = plane.buffer
        buffer.rewind()
        if (pixelStride == 4 && rowStride % 4 == 0 && buffer.remaining() >= rowStride * image.height) {
            val paddedWidth = rowStride / 4
            val bmp = sourceBitmap?.takeIf { it.width == paddedWidth && it.height == image.height }
                ?: Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888).also {
                    sourceBitmap?.recycle()
                    sourceBitmap = it
                }
            bmp.copyPixelsFromBuffer(buffer)
            return bmp
        }
        // Unusual stride/size: let CameraX do the conversion (allocates a new bitmap).
        return image.toBitmap()
    }

    /** Rotates the frame upright and scales it to the square model input in one draw. */
    private fun prepareInput(source: Bitmap, width: Int, height: Int, rotation: Int, size: Int): Bitmap {
        val input = inputBitmap?.takeIf { it.width == size }
            ?: Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).also {
                inputBitmap?.recycle()
                inputBitmap = it
            }
        val rotatedW = if (rotation % 180 == 0) width else height
        val rotatedH = if (rotation % 180 == 0) height else width
        matrix.reset()
        matrix.postTranslate(-width / 2f, -height / 2f)
        matrix.postRotate(rotation.toFloat())
        matrix.postScale(size.toFloat() / rotatedW, size.toFloat() / rotatedH)
        matrix.postTranslate(size / 2f, size / 2f)

        val canvas = Canvas(input)
        canvas.concat(matrix)
        // Only draw the real image area; row padding (if any) is excluded.
        srcRect.set(0, 0, width, height)
        dstRect.set(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawBitmap(source, srcRect, dstRect, paint)
        return input
    }

    private fun post(block: () -> Unit) {
        if (executor.isShutdown) return
        executor.execute(block)
    }

    private companion object {
        const val TAG = "FrameAnalyzer"
    }
}
