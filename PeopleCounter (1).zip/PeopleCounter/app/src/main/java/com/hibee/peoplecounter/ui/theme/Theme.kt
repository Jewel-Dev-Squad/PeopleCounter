package com.hibee.peoplecounter.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Detected = Color(0xFF4ADE80)
val Tentative = Color(0xFFFACC15)
val Warning = Color(0xFFFBBF24)
val ErrorRed = Color(0xFFF87171)
val CountLine = Color(0xFF38BDF8)

private val Colors = darkColorScheme(
    primary = Color(0xFF4ADE80),
    onPrimary = Color(0xFF052E16),
    secondary = Color(0xFF38BDF8),
    onSecondary = Color(0xFF082F49),
    background = Color(0xFF0F1720),
    onBackground = Color(0xFFE5E7EB),
    surface = Color(0xFF16212D),
    onSurface = Color(0xFFE5E7EB),
    surfaceVariant = Color(0xFF1F2D3B),
    onSurfaceVariant = Color(0xFFB6C2CF),
    error = ErrorRed,
)

/** A camera app reads best in a dark theme, so the scheme is fixed. */
@Composable
fun PeopleCounterTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
