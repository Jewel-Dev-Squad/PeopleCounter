package com.hibee.peoplecounter.detection

/**
 * Bundled, free, Apache-2.0 licensed COCO detection models.
 * Both were obtained from https://github.com/google-coral/test_data (Apache-2.0)
 * and verified with the LiteRT Python runtime before bundling.
 */
enum class ModelOption(
    val assetName: String,
    val inputSize: Int,
    val displayName: String,
    val description: String,
    val personClassId: Int = 0,
) {
    BALANCED(
        assetName = "efficientdet_lite0_320.tflite",
        inputSize = 320,
        displayName = "Balanced – EfficientDet-Lite0 (320 px)",
        description = "Better at small/far people. Recommended for most phones.",
    ),
    FAST(
        assetName = "ssd_mobilenet_v2_300.tflite",
        inputSize = 300,
        displayName = "Fast – SSD MobileNet V2 (300 px)",
        description = "Lighter model for older or slower phones.",
    );

    /** The model to try if this one fails to load or is too slow. */
    val fallback: ModelOption?
        get() = when (this) {
            BALANCED -> FAST
            FAST -> null
        }
}
