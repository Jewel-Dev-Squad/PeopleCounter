package com.hibee.peoplecounter.coverage

/**
 * Extension point for future versions: every sensor that can observe people
 * (this phone's camera, additional authorized cameras, LiDAR/radar units …)
 * is described as an [ObservationSource].
 *
 * A source only contributes to full-area coverage if it declares a
 * [ValidatedCoverage] – i.e. its detection range and field of view have been
 * measured/calibrated on site. A single phone camera has no validated range
 * (obstacles, distance and lighting all limit it), so it never does.
 */
interface ObservationSource {
    val id: String
    val displayName: String
    val validatedCoverage: ValidatedCoverage?
}

/**
 * A calibrated sector around the user's position.
 * Angles are compass bearings in degrees; the sector runs clockwise from
 * [startBearingDeg] to [endBearingDeg] (it may wrap past 360).
 */
data class ValidatedCoverage(
    val reliableRangeMeters: Float,
    val startBearingDeg: Float,
    val endBearingDeg: Float,
)

/** The phone's own rear camera. Range and coverage are never validated. */
object PhoneCameraSource : ObservationSource {
    override val id = "phone-rear-camera"
    override val displayName = "This phone's rear camera"
    override val validatedCoverage: ValidatedCoverage? = null
}

enum class CoverageLevel {
    /** Only what the camera happens to see is counted. */
    VISIBLE_ONLY,

    /** Some, but not all, of the target radius is covered by validated sources. */
    PARTIAL_VALIDATED,

    /** Validated sources cover 360° out to the target radius. */
    FULL_VALIDATED,
}

data class CoverageStatus(
    val level: CoverageLevel,
    val targetRadiusMeters: Int,
    val coveredDegrees: Float,
    val message: String,
)

object CoverageEvaluator {

    fun evaluate(targetRadiusMeters: Int, sources: List<ObservationSource>): CoverageStatus {
        val sectors = sources.mapNotNull { it.validatedCoverage }
            .filter { it.reliableRangeMeters >= targetRadiusMeters }
        val covered = coveredDegrees(sectors)
        return when {
            covered >= 359.999f -> CoverageStatus(
                CoverageLevel.FULL_VALIDATED, targetRadiusMeters, 360f,
                "Validated full coverage of the $targetRadiusMeters-meter radius.",
            )
            covered > 0f -> CoverageStatus(
                CoverageLevel.PARTIAL_VALIDATED, targetRadiusMeters, covered,
                "Partial coverage: ${covered.toInt()}° of the $targetRadiusMeters-meter radius is validated. " +
                    "People outside the covered sectors are not counted.",
            )
            else -> CoverageStatus(
                CoverageLevel.VISIBLE_ONLY, targetRadiusMeters, 0f,
                "Counting visible people only. Full $targetRadiusMeters-meter coverage is unavailable.",
            )
        }
    }

    /** Union of sectors on the circle, in degrees (0..360). */
    fun coveredDegrees(sectors: List<ValidatedCoverage>): Float {
        // Split wrapping sectors into [start, 360) and [0, end) intervals.
        val intervals = ArrayList<Pair<Float, Float>>()
        for (s in sectors) {
            val start = normalize(s.startBearingDeg)
            var span = s.endBearingDeg - s.startBearingDeg
            if (span <= 0f) span += 360f
            if (span >= 360f) return 360f
            val end = start + span
            if (end <= 360f) {
                intervals += start to end
            } else {
                intervals += start to 360f
                intervals += 0f to (end - 360f)
            }
        }
        if (intervals.isEmpty()) return 0f
        intervals.sortBy { it.first }
        var total = 0f
        var curStart = intervals[0].first
        var curEnd = intervals[0].second
        for (i in 1 until intervals.size) {
            val (s, e) = intervals[i]
            if (s <= curEnd) {
                if (e > curEnd) curEnd = e
            } else {
                total += curEnd - curStart
                curStart = s
                curEnd = e
            }
        }
        total += curEnd - curStart
        return total.coerceAtMost(360f)
    }

    private fun normalize(deg: Float): Float = ((deg % 360f) + 360f) % 360f
}
