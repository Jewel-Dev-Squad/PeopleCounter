package com.hibee.peoplecounter

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.hibee.peoplecounter.ui.PeopleCounterScreen
import com.hibee.peoplecounter.ui.PeopleCounterViewModel
import com.hibee.peoplecounter.ui.PrivacyScreen
import com.hibee.peoplecounter.ui.SettingsScreen
import com.hibee.peoplecounter.ui.theme.PeopleCounterTheme

private enum class Screen { MAIN, SETTINGS, PRIVACY }

class MainActivity : ComponentActivity() {

    private val viewModel: PeopleCounterViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PeopleCounterTheme {
                var screen by rememberSaveable { mutableStateOf(Screen.MAIN) }
                val ui by viewModel.ui.collectAsStateWithLifecycle()

                // Keep the screen on only while the camera is counting.
                LaunchedEffect(ui.cameraActive) {
                    if (ui.cameraActive) {
                        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    } else {
                        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                }

                when (screen) {
                    Screen.MAIN -> PeopleCounterScreen(
                        viewModel = viewModel,
                        onOpenSettings = {
                            viewModel.onLeaveCameraScreen()
                            screen = Screen.SETTINGS
                        },
                        onOpenPrivacy = {
                            viewModel.onLeaveCameraScreen()
                            screen = Screen.PRIVACY
                        },
                    )
                    Screen.SETTINGS -> SettingsScreen(viewModel) {
                        screen = Screen.MAIN
                        viewModel.onReturnToCameraScreen()
                    }
                    Screen.PRIVACY -> PrivacyScreen {
                        screen = Screen.MAIN
                        viewModel.onReturnToCameraScreen()
                    }
                }
            }
        }
    }
}
