package com.hibee.peoplecounter.detection

import android.graphics.Bitmap
import com.hibee.peoplecounter.counting.Gender
import java.io.Closeable

/**
 * Estimates the gender of one detected person. The bundled COCO models only
 * know the class "person", so gender needs a separate model; plug one in here.
 *
 * Not bundled: [Unavailable] is used until a classifier is added, and every
 * person is then counted (and announced) as gender unknown.
 */
interface GenderClassifier : Closeable {
    /** False for [Unavailable]; lets the analyzer skip per-person work. */
    val isAvailable: Boolean

    /**
     * @param frame the upright model input bitmap the detections were made on
     * @param box the person's box in normalized coordinates of [frame]
     * @return [Gender.UNKNOWN] when unsure (e.g. face not visible)
     */
    fun classify(frame: Bitmap, box: BoundingBox): Gender

    object Unavailable : GenderClassifier {
        override val isAvailable = false
        override fun classify(frame: Bitmap, box: BoundingBox) = Gender.UNKNOWN
        override fun close() = Unit
    }
}
