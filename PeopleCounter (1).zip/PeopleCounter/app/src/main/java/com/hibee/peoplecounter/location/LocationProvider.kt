package com.hibee.peoplecounter.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** The user's OWN position. This app never locates other people. */
sealed interface LocationState {
    data object Disabled : LocationState
    data object PermissionMissing : LocationState
    data object ProviderOff : LocationState
    data object Waiting : LocationState
    data class Available(val latitude: Double, val longitude: Double, val accuracyMeters: Float?) : LocationState
}

/**
 * Optional, framework-only (no Google Play services) location provider.
 * Used only to show where the target radius is centred; it is NOT a way to
 * find or count people – people who have not shared their location are
 * invisible to GPS.
 */
class LocationProvider(context: Context) {

    private val appContext = context.applicationContext
    private val manager = appContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager?

    private val _state = MutableStateFlow<LocationState>(LocationState.Disabled)
    val state: StateFlow<LocationState> = _state.asStateFlow()

    private var listening = false
    private var wanted = false

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) = publish(location)

        @Deprecated("Deprecated in API 29")
        override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) = Unit
        override fun onProviderEnabled(provider: String) {
            if (wanted && !listening) start()
        }

        override fun onProviderDisabled(provider: String) {
            if (manager?.let { m -> enabledProviders(m).isEmpty() } != false) {
                _state.value = LocationState.ProviderOff
            }
        }
    }

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(appContext, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(appContext, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    /** Starts low-frequency updates (every 10 s / 5 m). Main thread. */
    @SuppressLint("MissingPermission") // checked by hasPermission(); SecurityException handled
    fun start() {
        wanted = true
        if (listening) return
        val m = manager
        if (m == null) {
            _state.value = LocationState.ProviderOff
            return
        }
        if (!hasPermission()) {
            _state.value = LocationState.PermissionMissing
            return
        }
        val providers = enabledProviders(m)
        if (providers.isEmpty()) {
            _state.value = LocationState.ProviderOff // retried by refresh() when the app resumes
            return
        }
        try {
            _state.value = LocationState.Waiting
            providers.mapNotNull { m.getLastKnownLocation(it) }
                .maxByOrNull { it.time }
                ?.let(::publish)
            for (p in providers) {
                m.requestLocationUpdates(p, 10_000L, 5f, listener, Looper.getMainLooper())
            }
            listening = true
        } catch (e: SecurityException) {
            _state.value = LocationState.PermissionMissing
        }
    }

    /** Retry after the user may have changed permissions or turned location on (call on resume). */
    fun refresh() {
        if (wanted && !listening) start()
    }

    fun stop(disabled: Boolean = true) {
        wanted = false
        manager?.removeUpdates(listener)
        listening = false
        if (disabled) _state.value = LocationState.Disabled
    }

    private fun publish(location: Location) {
        _state.value = LocationState.Available(
            latitude = location.latitude,
            longitude = location.longitude,
            accuracyMeters = if (location.hasAccuracy()) location.accuracy else null,
        )
    }

    /** GPS needs FINE permission; with only COARSE we use the network provider. */
    private fun enabledProviders(m: LocationManager): List<String> {
        val fine = ContextCompat.checkSelfPermission(appContext, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        val candidates = if (fine) {
            listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        } else {
            listOf(LocationManager.NETWORK_PROVIDER)
        }
        return candidates.filter { runCatching { m.isProviderEnabled(it) }.getOrDefault(false) }
    }
}
