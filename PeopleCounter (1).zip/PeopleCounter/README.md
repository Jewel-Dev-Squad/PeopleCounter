# People Counter (offline, free, Android)

People Counter counts the people its rear camera can see, in real time. It runs entirely on the phone: Kotlin, Jetpack Compose, CameraX and LiteRT (TensorFlow Lite), with two bundled Apache-2.0 detection models.

It needs **no paid API, API key, account, cloud service or network connection**. The app does not even request the `INTERNET` permission.

> **What it does not do:** it does not count everyone within 100 m. One phone camera only sees what is in front of it, until people are too small to detect. It cannot see behind you, through walls or crowds, and it cannot measure distance. The app always shows *"Counting visible people only. Full 100-meter coverage is unavailable."* and never shows a count for the whole radius.

---

## 1. Verification status

| Item | Status |
|---|---|
| Model choice, license, tensor layout, person class = 0 | **Verified.** Both models were run with the LiteRT Python runtime on test photos (results in §3). |
| Core logic: detection decoding, tracker, counting engine, line crossing, coverage, overlay maths, throttle, performance monitor | **Verified.** Compiled with `kotlinc` 2.0.21 and **35 JUnit tests pass**. One test uses a golden fixture of real model output. |
| Android layer: CameraX, LiteRT on Android, Compose UI, permissions, location | **Written, reviewed, not compiled.** The build environment used to write this project could not reach Google's Maven repository or download the Android SDK. Run `./gradlew assembleDebug` first, and see §11 if anything needs adjusting. |
| Debug APK | **Not built yet.** Build it with §6. |
| Instrumented tests (real model on device) | **Written, not run.** They need a device or emulator (§7). |
| Behaviour on a physical phone (FPS, accuracy) | **Not measured.** Use the test plan in §8. The app measures and shows real inference time and FPS; it never assumes a value. |

---

## 2. Project structure

```
PeopleCounter/
├── settings.gradle.kts, build.gradle.kts, gradle.properties
├── gradle/libs.versions.toml            # all dependency versions in one place
├── gradle/wrapper/                      # Gradle 8.11.1 wrapper
├── app/
│   ├── build.gradle.kts
│   ├── src/main/AndroidManifest.xml     # CAMERA + optional location, no INTERNET
│   ├── src/main/assets/
│   │   ├── efficientdet_lite0_320.tflite   # Balanced model (4.4 MB)
│   │   └── ssd_mobilenet_v2_300.tflite     # Fast / fallback model (5.9 MB)
│   ├── src/main/java/com/hibee/peoplecounter/
│   │   ├── MainActivity.kt
│   │   ├── camera/      CameraController.kt   CameraX preview + analysis binding
│   │   │                FrameAnalyzer.kt      frame → upright bitmap → model → engine (background thread)
│   │   │                PerformanceMonitor.kt FrameThrottle + measured latency/FPS
│   │   ├── detection/   PersonDetector.kt     interface + LiteRT implementation
│   │   │                DetectionDecoder.kt   raw tensors → person boxes (+ NMS)
│   │   │                DetectionResult.kt    BoundingBox / Detection / DetectionFrame
│   │   │                ModelOption.kt        bundled models and fallback order
│   │   ├── tracking/    ObjectTracker.kt      IoU + centre-distance tracker, temporary IDs
│   │   ├── counting/    PeopleCountingEngine.kt  visible / unique / in-out counts
│   │   │                LineCrossingCounter.kt   virtual line with hysteresis
│   │   ├── coverage/    Coverage.kt           ObservationSource interface + honest coverage evaluation
│   │   ├── location/    LocationProvider.kt   optional, framework LocationManager (no Play services)
│   │   ├── settings/    AppSettings.kt, SettingsRepository.kt
│   │   └── ui/          PeopleCounterScreen, CameraPreview, SettingsScreen, PrivacyScreen,
│   │                    PeopleCounterViewModel, components/ (overlay, panels), theme/
│   ├── src/test/        JVM unit tests (35)
│   └── src/androidTest/ instrumented model tests + test image
├── licenses/            NOTICE.md + Apache-2.0 text
└── tools/               download_models.sh, verify_model.py, inspect_model.py,
                         make_fixture.py, run_core_tests.sh
```

Camera, detection, tracking, counting, coverage, location, settings and UI each have their own package. Everything under `detection/` (except `PersonDetector.kt`), `tracking/`, `counting/` and `coverage/` is plain Kotlin with no Android dependencies, which is why it can be unit-tested on the JVM.

---

## 3. AI model: selection, license, how to get it

**Selected:** EfficientDet-Lite0 (320×320, int8 post-training quantized, COCO) is the default "Balanced" model. SSD MobileNet V2 (300×300, quantized, COCO) is the "Fast" model and the automatic fallback.

- **License:** Apache License 2.0. Both files come from [`google-coral/test_data`](https://github.com/google-coral/test_data), an Apache-2.0 repository. Redistributing them inside an APK is allowed if the license text is kept (`licenses/`).
- **Why not YOLOv5/v8/11?** Ultralytics models are AGPL-3.0, which brings source-disclosure obligations. The Apache-2.0 models avoid that.
- **Android compatibility:** both have uint8 input `[1, H, W, 3]` and the standard `TFLite_Detection_PostProcess` outputs (boxes `[1,N,4]` as ymin/xmin/ymax/xmax, classes `[1,N]`, scores `[1,N]`, count `[1]`). Both run on LiteRT's built-in CPU kernels (XNNPACK), so no custom ops or delegates are needed.

**What was checked here** (LiteRT Python 2.3.0; *desktop x86 CPU, not phone numbers*):

| Photo | EfficientDet-Lite0 people (score ≥ 0.4) | SSD MobileNet V2 |
|---|---|---|
| Single portrait | 1 (0.96) | 1 (0.80) |
| Street scene, 4 people (1 cut off at the edge) + bus | 3 | 3 |
| Two people, close-up | 2 | 2 |
| Plain grey image | 0 | 0 |

**The models are already in `app/src/main/assets/`.** To re-download them and check their SHA-256:

```bash
tools/download_models.sh
```

Or by hand:
1. Download `efficientdet_lite0_320_ptq.tflite` and `ssd_mobilenet_v2_coco_quant_postprocess.tflite` from `https://raw.githubusercontent.com/google-coral/test_data/master/`.
2. Save them as `app/src/main/assets/efficientdet_lite0_320.tflite` and `app/src/main/assets/ssd_mobilenet_v2_300.tflite`.
3. Leave them uncompressed. `app/build.gradle.kts` already sets `noCompress += "tflite"` so they can be memory-mapped.

To inspect or test a model on a desktop: `pip install ai-edge-litert numpy pillow`, then run `python3 tools/inspect_model.py <model>` or `python3 tools/verify_model.py <model> photo.jpg`.

---

## 4. Implemented features

**Camera**
- The rear camera opens only after you press **Start Counting**.
- Camera permission is requested at runtime, with a rationale dialog. If it is denied, you see an explanation, a retry button, or "Open app settings" once it has been denied permanently.
- "Camera Unavailable" is shown when the device has no rear camera, binding fails, or the model fails to load.

**Detection**
- Person class only, with a configurable confidence threshold and an extra non-max suppression (NMS) pass.
- Boxes are drawn over the preview. Solid green means a counted (confirmed) person; dashed yellow means not yet confirmed.
- Inference runs on a single background thread. CameraX `STRATEGY_KEEP_ONLY_LATEST` drops frames while the model is busy, so jobs never pile up. An optional rate cap (5/10/15 per second, or Max) saves battery. The UI always shows the latest result.

**Tracking**
- Greedy IoU matching with a centre-distance fallback for fast motion or low FPS, plus constant-velocity prediction.
- A track is confirmed after 3 hits, which removes most one-frame false positives.
- A confirmed track survives 1.5 s of occlusion. Visible-count gaps under 0.4 s are bridged so the number does not flicker.
- Pausing, opening Settings, or sending the app to the background keeps existing tracks, so people still in place keep their IDs.

**Counting**
- **Visible now:** the main number.
- **Tracked total (est.):** distinct confirmed tracks since start or reset, clearly labelled as an estimate.
- **Optional In/Out line:** horizontal or vertical, adjustable position and direction, with a dead band against jitter.
- An in-app "What do these mean?" dialog explains the difference between the counts.

**Controls:** Start, Pause, Resume, Stop and Reset. **Stop** unbinds the camera, closes the interpreter and stops location updates.

**100 m requirement**
- You can choose a radius (25, 50 or **100 m**, default 100).
- Optional location shows *your* position as the radius centre. It uses framework `LocationManager`, not Google Play services.
- `CoverageEvaluator` reports VISIBLE_ONLY / PARTIAL / FULL. FULL is only possible when validated sensors covering 360° out to the radius are registered as `ObservationSource`s, which a single phone never is.

**Settings:** model (Balanced/Fast), analysis resolution (640×480 or 1280×960), detection rate, CPU threads, confidence, radius, line options, show IDs, location.

**Performance**
- Measured inference time and FPS are shown on screen.
- A slow-device banner offers to switch to the Fast model.
- If the selected model fails to load, or fails 3 frames in a row, the app falls back to the Fast model automatically.
- Bitmaps and buffers are reused on the analysis path.

**Privacy**
- No `INTERNET` permission, and nothing is recorded or saved.
- Backups and device transfer are disabled.
- An in-app Privacy screen explains each permission and lists the open-source components.
- The screen stays on only while counting.

---

## 5. Requirements

- Android Studio Ladybug (2024.2) or newer, which bundles JDK 17/21.
- Android SDK Platform 35 (installed by Android Studio when prompted).
- A phone running Android 8.0 (API 26) or newer, with a rear camera.

---

## 6. Build and run

**Android Studio:** File → Open → select the `PeopleCounter` folder → let Gradle sync → pick your phone → Run ▶.

**Command line:**

```bash
cd PeopleCounter
./gradlew assembleDebug                        # builds the debug APK
# APK: app/build/outputs/apk/debug/app-debug.apk
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

The first build downloads Gradle 8.11.1 and the dependencies (all free, from Google Maven and Maven Central). After that, the app itself needs no network.

**Install without a cable:** copy `app-debug.apk` to the phone, open it, and allow "Install unknown apps" for your file manager.

**Release APK:** run `./gradlew assembleRelease`, then sign it with your own keystore (Build → Generate Signed App Bundle/APK in Android Studio).

**Enable USB debugging:** Settings → About phone → tap *Build number* 7 times → Developer options → *USB debugging*.

---

## 7. Automated tests

```bash
./gradlew testDebugUnitTest            # 35 JVM tests (decoder, tracker, engine, line, coverage, overlay, throttle)
./gradlew connectedDebugAndroidTest    # on a connected phone/emulator: loads both real models,
                                       # expects 1 person in a portrait, 0 in a blank image,
                                       # and logs the measured inference time for that device
```

Without the Android SDK, you can run the same 35 JVM tests with plain Kotlin:

```bash
JUNIT_CP=junit-4.13.2.jar:hamcrest-core-1.3.jar KOTLINC=/path/to/kotlinc tools/run_core_tests.sh
```

This is how they were run while writing the project. Result: `OK (35 tests)`.

---

## 8. Testing on a physical phone

For each scenario, note the visible count, the measured ms/FPS (top-right badge) and any wrong boxes.

| # | Scenario | What to expect / check |
|---|---|---|
| 1 | One person standing 2–5 m away | Count becomes 1 within about 0.3 s (3 frames). The ID stays stable while they stand still. |
| 2 | 3–6 people side by side | Each gets one box and one ID. Count matches the people clearly in view. |
| 3 | People walking across the view | IDs stay the same while walking. *Tracked total* goes up once per person. With the line on, In/Out goes up once per crossing. |
| 4 | People partly hidden behind others | Expect some misses. Short occlusions (< 1.5 s) keep the ID; longer ones may create a new ID (total over-counts). |
| 5 | Low light | Expect fewer detections and lower scores. Try a lower confidence threshold in Settings. |
| 6 | Empty scene | Count stays 0. Note any false boxes (posters, mannequins and statues can trigger them). |
| 7 | Deny camera permission | "Camera Unavailable" with an explanation. Deny again → "Open app settings" appears. Grant it in Settings and return → status becomes Ready. |
| 8 | Pause → Resume, Home → back, open Settings → back | Status shows Paused, then Detecting. People still in view keep their IDs, and the total does not jump. |
| 9 | Stop | Camera indicator turns off. The last counts stay; the next Start begins a fresh session. |
| 10 | Slow/old phone | Read the measured ms and FPS. If it is slow, accept "Use Fast model", reduce threads, or cap the rate. |
| 11 | Distance | Walk away from the camera and note when detection stops. This is the real working range on that phone, typically far less than 100 m. |

---

## 9. Known limitations

- **Coverage:** only the camera's field of view (about 60–80° horizontally on most phones), and only what is not blocked. People behind the user, behind obstacles or in dense crowds are not seen.
- **Range:** people far away are only a few pixels tall at the model's 320×320 input. Expect detection to fall off well before 100 m. The range is not measured or validated.
- **No distance estimation:** the app cannot tell whether a detected person is inside 100 m.
- **Tracking:** there is no appearance re-identification. Long occlusions, or someone leaving and re-entering, create new IDs, so *Tracked total* is an estimate. Crowds with heavy overlap merge or miss people.
- **Model accuracy:** COCO-trained models miss unusual poses, very small people and people in poor light, and sometimes detect person-like objects. Counts are never guaranteed to be exact.
- **Camera motion:** panning quickly breaks tracks. Hold the phone steady or mount it.
- **Portrait only.** Rotation is handled for sensor orientation, but the UI is locked to portrait.
- Battery and heat increase with continuous counting. Use the rate cap for long sessions.

---

## 10. What is implemented vs. what needs extra hardware

| Capability | Status |
|---|---|
| Counting people visible to this phone's camera | **Implemented** |
| Stable temporary IDs, cumulative estimate, In/Out line | **Implemented** |
| Showing the user's own GPS position and a 100 m target radius | **Implemented** (optional) |
| Honest coverage indicator (visible only / partial / full) | **Implemented** |
| Architecture for more sensors (`ObservationSource` + `ValidatedCoverage`, sector union) | **Implemented** (interface only) |
| Counting everyone within 100 m in all directions | **Needs extra hardware:** several authorised, calibrated cameras or sensors (e.g. 360° camera rigs, LiDAR or radar people counters) covering every sector to 100 m, plus a validation study on site |
| Distance to each person | **Needs** a depth sensor (ToF/LiDAR), stereo cameras, or a validated monocular method with per-site calibration |
| Counting people who are not in line of sight | Not possible with cameras. GPS cannot locate people who have not shared their location, and this app does not try. |

---

## 11. If the first build reports a problem

The Android layer could not be compiled while writing the project (no access to Google Maven). These are the places most likely to need a small change:

- **`setUseXNNPACK`** (detection/PersonDetector.kt). If the LiteRT version you use rejects it, delete the line; XNNPACK is the default CPU backend anyway.
- **Dependency versions** are all in `gradle/libs.versions.toml`. Android Studio's "Upgrade" hints are safe to accept.
- **16 KB page-size devices (Android 15+):** if Play warns about native-library alignment, upgrade `litert` to the newest 1.x release.

---

## 12. Future improvements

- GPU delegate (`litert-gpu`) or NNAPI/NPU acceleration, with automatic benchmarking.
- Appearance embeddings (lightweight re-ID) to reduce double counting after occlusion.
- A Kalman-filter tracker (SORT/ByteTrack-style) with low-score second-pass matching.
- Region-of-interest counting zones (polygons) in addition to the line.
- Integration with additional, authorised fixed cameras or sensors via `ObservationSource`.
- Optional CSV export of counts only (never images), behind an explicit opt-in.
- Landscape and tablet layouts.
