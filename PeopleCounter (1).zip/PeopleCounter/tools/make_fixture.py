"""Regenerates the golden test fixture (BusPhotoFixture.kt) from a real model run.
Usage: python3 tools/make_fixture.py app/src/main/assets/efficientdet_lite0_320.tflite bus.jpg"""
import sys, numpy as np
from PIL import Image
from ai_edge_litert.interpreter import Interpreter
m, img = sys.argv[1], sys.argv[2]
it = Interpreter(model_path=m); it.allocate_tensors()
inp = it.get_input_details()[0]; h, w = inp['shape'][1:3]
im = Image.open(img).convert('RGB')
it.set_tensor(inp['index'], np.expand_dims(np.asarray(im.resize((w, h))), 0).astype(np.uint8)); it.invoke()
b, c, s, n = [it.get_tensor(o['index']) for o in it.get_output_details()]
f = lambda x: f"{x:.5f}f"
print("    val BOXES = arrayOf(\n" + ",\n".join("        floatArrayOf(" + ", ".join(f(v) for v in r) + ")" for r in b[0]) + ",\n    )")
print("    val CLASSES = floatArrayOf(" + ", ".join(f(v) for v in c[0]) + ")")
print("    val SCORES = floatArrayOf(" + ", ".join(f(v) for v in s[0]) + ")")
print(f"    const val COUNT = {int(n[0])}")
