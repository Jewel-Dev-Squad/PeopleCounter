"""Prints input/output tensor names, shapes and types of .tflite models.
Usage: python3 tools/inspect_model.py app/src/main/assets/*.tflite"""
import sys
from ai_edge_litert.interpreter import Interpreter
for p in sys.argv[1:]:
    it = Interpreter(model_path=p); it.allocate_tensors()
    print(p)
    for d in it.get_input_details(): print(" IN ", d['name'], d['shape'], d['dtype'].__name__, d['quantization'])
    for d in it.get_output_details(): print(" OUT", d['index'], d['name'], d['shape'], d['dtype'].__name__, d['quantization'])
