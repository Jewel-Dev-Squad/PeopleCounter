#!/usr/bin/env bash
# Re-downloads the two bundled, Apache-2.0 licensed COCO detection models into
# app/src/main/assets and verifies their SHA-256 checksums.
# Source: https://github.com/google-coral/test_data (Apache License 2.0)
set -euo pipefail
cd "$(dirname "$0")/../app/src/main/assets"
BASE=https://raw.githubusercontent.com/google-coral/test_data/master
curl -fL -o efficientdet_lite0_320.tflite "$BASE/efficientdet_lite0_320_ptq.tflite"
curl -fL -o ssd_mobilenet_v2_300.tflite   "$BASE/ssd_mobilenet_v2_coco_quant_postprocess.tflite"
sha256sum -c <<'SUMS'
33a3b622c7cac0762f96089353cd61495f3e993968d133af7871bfc2d5396704  efficientdet_lite0_320.tflite
42fb3d70ffb7bb37dd518f730f7be784b831c2078f30c497d0019cc2e987fa26  ssd_mobilenet_v2_300.tflite
SUMS
echo "Models ready."
