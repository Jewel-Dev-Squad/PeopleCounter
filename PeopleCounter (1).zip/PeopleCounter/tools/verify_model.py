"""Runs a bundled model on photos and prints person boxes (score >= 0.4).
Usage: pip install ai-edge-litert numpy pillow
       python3 tools/verify_model.py app/src/main/assets/efficientdet_lite0_320.tflite photo1.jpg [photo2.jpg ...]"""
import sys, numpy as np
from PIL import Image
from ai_edge_litert.interpreter import Interpreter
m = sys.argv[1]
it = Interpreter(model_path=m, num_threads=2); it.allocate_tensors()
inp = it.get_input_details()[0]; h, w = inp['shape'][1:3]
outs = it.get_output_details()
for p in sys.argv[2:]:
    img = Image.open(p).convert('RGB'); W, H = img.size
    it.set_tensor(inp['index'], np.expand_dims(np.asarray(img.resize((w, h))), 0).astype(np.uint8))
    it.invoke()
    boxes, cls, sc, n = [it.get_tensor(o['index']) for o in outs]
    people = [(round(float(s),2), [int(boxes[0][i][1]*W), int(boxes[0][i][0]*H), int(boxes[0][i][3]*W), int(boxes[0][i][2]*H)]) for i, (c, s) in enumerate(zip(cls[0], sc[0])) if int(c) == 0 and s >= 0.4]
    print(m.split('/')[-1][:20], p, (W,H), 'people>=0.4:', len(people), people)
