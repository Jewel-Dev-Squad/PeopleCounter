package com.hibee.peoplecounter.detection

import com.hibee.peoplecounter.settings.AppSettings
import com.hibee.peoplecounter.settings.DetectionMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CocoLabelsTest {

    @Test
    fun indicesVerifiedWithRealModels() {
        // Observed with both bundled models on test photos (tools/verify_labels.py).
        val observed = mapOf(0 to "person", 5 to "bus", 15 to "bird", 16 to "cat", 17 to "dog",
            36 to "sports ball", 37 to "kite", 54 to "orange")
        observed.forEach { (id, name) -> assertEquals(name, CocoLabels.nameFor(id)) }
    }

    @Test
    fun has80RealClasses_inExactly12Categories() {
        assertEquals(80, CocoLabels.classCount)
        assertEquals(80, Category.entries.sumOf { CocoLabels.namesIn(it).size })
        assertNull(CocoLabels.labelFor(11)) // unused slot
        assertNull(CocoLabels.labelFor(-1))
        assertNull(CocoLabels.labelFor(90))
    }

    @Test
    fun settings_modeDecidesTheClassFilter() {
        assertNull(AppSettings().allowedClassIds()) // default: all objects
        assertEquals(setOf(0), AppSettings(mode = DetectionMode.PEOPLE).allowedClassIds())
        val animals = AppSettings(enabledCategories = setOf(Category.ANIMALS)).allowedClassIds()!!
        assertEquals(10, animals.size)
        assertTrue(17 in animals) // dog
        assertTrue(AppSettings(enabledCategories = emptySet()).allowedClassIds()!!.isEmpty())
    }
}
