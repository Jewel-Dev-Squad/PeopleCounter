package com.hibee.peoplecounter.detection

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DetectionDecoderTest {

    @Test
    fun realModelOutput_keepsOnlyPeopleAboveThreshold() {
        val people = DetectionDecoder.decode(
            BusPhotoFixture.BOXES, BusPhotoFixture.CLASSES, BusPhotoFixture.SCORES,
            BusPhotoFixture.COUNT, allowedClassIds = setOf(CocoLabels.PERSON), minScore = 0.5f,
        )
        // The bus (class 5, score 0.80) must be excluded; three people pass 0.5.
        assertEquals(3, people.size)
        assertTrue(people.all { it.score >= 0.5f })
        assertEquals(0.789f, people[0].score, 0.01f)
    }

    @Test
    fun realModelOutput_boxesAreConvertedFromYxyxToLtrb() {
        val first = DetectionDecoder.decode(
            BusPhotoFixture.BOXES, BusPhotoFixture.CLASSES, BusPhotoFixture.SCORES,
            BusPhotoFixture.COUNT, minScore = 0.5f,
        ).first().box
        // Row 1 of the fixture: ymin=0.36755, xmin=0.06509, ymax=0.84097, xmax=0.28917
        assertEquals(0.06509f, first.left, 1e-4f)
        assertEquals(0.36755f, first.top, 1e-4f)
        assertEquals(0.28917f, first.right, 1e-4f)
        assertEquals(0.84097f, first.bottom, 1e-4f)
    }

    @Test
    fun lowerThreshold_returnsMoreDetections() {
        val strict = DetectionDecoder.decode(
            BusPhotoFixture.BOXES, BusPhotoFixture.CLASSES, BusPhotoFixture.SCORES,
            BusPhotoFixture.COUNT, minScore = 0.6f,
        )
        val loose = DetectionDecoder.decode(
            BusPhotoFixture.BOXES, BusPhotoFixture.CLASSES, BusPhotoFixture.SCORES,
            BusPhotoFixture.COUNT, minScore = 0.25f,
        )
        assertTrue(loose.size >= strict.size)
        assertEquals(3, strict.size)
    }

    @Test
    fun allClasses_includesTheBusAndThePeople() {
        val all = DetectionDecoder.decode(
            BusPhotoFixture.BOXES, BusPhotoFixture.CLASSES, BusPhotoFixture.SCORES,
            BusPhotoFixture.COUNT, allowedClassIds = null, minScore = 0.5f,
        )
        assertEquals(4, all.size)
        assertEquals(1, all.count { CocoLabels.nameFor(it.classId) == "bus" })
        assertEquals(3, all.count { CocoLabels.nameFor(it.classId) == "person" })
    }

    @Test
    fun categoryFilter_keepsOnlyVehicles() {
        val vehicles = DetectionDecoder.decode(
            BusPhotoFixture.BOXES, BusPhotoFixture.CLASSES, BusPhotoFixture.SCORES,
            BusPhotoFixture.COUNT, allowedClassIds = CocoLabels.classIdsIn(setOf(Category.VEHICLES)),
            minScore = 0.5f,
        )
        assertEquals(listOf("bus"), vehicles.map { CocoLabels.nameFor(it.classId) })
    }

    @Test
    fun unusedLabelSlots_areDroppedWhenKeepingAllClasses() {
        val boxes = arrayOf(floatArrayOf(0.1f, 0.1f, 0.5f, 0.3f), floatArrayOf(0.1f, 0.5f, 0.5f, 0.7f))
        // 11 is an unused "n/a" slot in the COCO label map; 200 is out of range.
        val out = DetectionDecoder.decode(boxes, floatArrayOf(11f, 200f), floatArrayOf(0.9f, 0.9f), 2, allowedClassIds = null)
        assertTrue(out.isEmpty())
    }

    @Test
    fun nms_doesNotMergeDifferentClassesThatOverlap() {
        val person = Detection(BoundingBox(0.1f, 0.1f, 0.5f, 0.9f), 0.9f, classId = 0)
        val backpack = Detection(BoundingBox(0.12f, 0.12f, 0.5f, 0.88f), 0.8f, classId = 26)
        assertEquals(2, DetectionDecoder.nonMaxSuppression(listOf(person, backpack), 0.6f).size)
    }

    @Test
    fun emptyOutput_returnsNoDetections() {
        val people = DetectionDecoder.decode(emptyArray(), FloatArray(0), FloatArray(0), 0)
        assertTrue(people.isEmpty())
    }

    @Test
    fun countLargerThanArrays_isClamped() {
        val boxes = arrayOf(floatArrayOf(0.1f, 0.1f, 0.5f, 0.3f))
        val people = DetectionDecoder.decode(boxes, floatArrayOf(0f), floatArrayOf(0.9f), count = 25)
        assertEquals(1, people.size)
    }

    @Test
    fun invalidAndNanBoxes_areDropped() {
        val boxes = arrayOf(
            floatArrayOf(0.5f, 0.5f, 0.4f, 0.6f), // ymax < ymin
            floatArrayOf(Float.NaN, 0.1f, 0.5f, 0.3f),
            floatArrayOf(0.1f, 0.1f, 0.5f, 0.3f), // valid
        )
        val people = DetectionDecoder.decode(
            boxes, floatArrayOf(0f, 0f, 0f), floatArrayOf(0.9f, 0.9f, 0.9f), 3,
        )
        assertEquals(1, people.size)
    }

    @Test
    fun outOfRangeCoordinates_areClamped() {
        val boxes = arrayOf(floatArrayOf(-0.2f, -0.1f, 1.3f, 0.5f))
        val box = DetectionDecoder.decode(boxes, floatArrayOf(0f), floatArrayOf(0.9f), 1).single().box
        assertEquals(0f, box.left, 0f)
        assertEquals(0f, box.top, 0f)
        assertEquals(1f, box.bottom, 0f)
    }

    @Test
    fun nms_removesDuplicateBoxesOfSamePerson() {
        val a = Detection(BoundingBox(0.1f, 0.1f, 0.4f, 0.9f), 0.9f)
        val b = Detection(BoundingBox(0.11f, 0.12f, 0.41f, 0.9f), 0.7f)
        val c = Detection(BoundingBox(0.6f, 0.1f, 0.9f, 0.9f), 0.8f)
        val kept = DetectionDecoder.nonMaxSuppression(listOf(b, a, c), 0.6f)
        assertEquals(listOf(a, c), kept)
    }

    @Test
    fun iou_ofIdenticalBoxesIsOne_andDisjointIsZero() {
        val a = BoundingBox(0f, 0f, 0.5f, 0.5f)
        assertEquals(1f, a.iou(a), 1e-6f)
        assertEquals(0f, a.iou(BoundingBox(0.6f, 0.6f, 0.9f, 0.9f)), 0f)
        assertEquals(1f / 7f, a.iou(BoundingBox(0.25f, 0.25f, 0.75f, 0.75f)), 1e-5f)
    }
}
