package com.hibee.peoplecounter.counting

import com.hibee.peoplecounter.detection.BoundingBox
import com.hibee.peoplecounter.detection.Detection
import com.hibee.peoplecounter.detection.DetectionFrame
import org.junit.Assert.assertEquals
import org.junit.Test

class PeopleCountingEngineTest {

    private fun frame(t: Long, vararg centers: Pair<Float, Float>) = DetectionFrame(
        detections = centers.map { (cx, cy) ->
            Detection(BoundingBox(cx - 0.07f, cy - 0.15f, cx + 0.07f, cy + 0.15f), 0.8f)
        },
        frameWidth = 480, frameHeight = 640, inferenceTimeMs = 30, timestampMs = t,
    )

    @Test
    fun emptyView_countsZero() {
        val engine = PeopleCountingEngine()
        var s = CountingSnapshot.EMPTY
        for (i in 0 until 10) s = engine.process(frame(i * 100L))
        assertEquals(0, s.visibleCount)
        assertEquals(0, s.uniqueTracked)
    }

    @Test
    fun samePeopleOverManyFrames_areCountedOnce() {
        val engine = PeopleCountingEngine()
        var s = CountingSnapshot.EMPTY
        for (i in 0 until 50) s = engine.process(frame(i * 100L, 0.2f to 0.5f, 0.5f to 0.5f, 0.8f to 0.5f))
        assertEquals(3, s.visibleCount)
        assertEquals(3, s.uniqueTracked)
    }

    @Test
    fun visibleCount_waitsForConfirmation() {
        val engine = PeopleCountingEngine()
        assertEquals(0, engine.process(frame(0, 0.5f to 0.5f)).visibleCount)
        assertEquals(0, engine.process(frame(100, 0.5f to 0.5f)).visibleCount)
        assertEquals(1, engine.process(frame(200, 0.5f to 0.5f)).visibleCount)
    }

    @Test
    fun singleMissedDetection_doesNotFlickerVisibleCount() {
        val engine = PeopleCountingEngine(EngineConfig(visibleGraceMs = 400))
        for (i in 0 until 5) engine.process(frame(i * 100L, 0.5f to 0.5f))
        assertEquals(1, engine.process(frame(500)).visibleCount) // missed once
        assertEquals(0, engine.process(frame(1_000)).visibleCount) // gone for 600 ms
    }

    @Test
    fun personLeavingAndNewPersonArriving_increasesCumulativeCount() {
        val engine = PeopleCountingEngine()
        var t = 0L
        repeat(5) { engine.process(frame(t, 0.3f to 0.5f)); t += 100 }
        repeat(20) { engine.process(frame(t)); t += 100 } // first person gone
        var s = CountingSnapshot.EMPTY
        repeat(5) { s = engine.process(frame(t, 0.7f to 0.5f)); t += 100 }
        assertEquals(1, s.visibleCount)
        assertEquals(2, s.uniqueTracked)
    }

    @Test
    fun lineCrossing_countsEntriesAndExits() {
        val engine = PeopleCountingEngine(
            EngineConfig(countingLine = CountingLine(LineOrientation.HORIZONTAL, 0.5f, 0.04f)),
        )
        var t = 0L
        var s = CountingSnapshot.EMPTY
        // Person walks down (top -> bottom) = entry.
        for (i in 0..12) { s = engine.process(frame(t, 0.5f to 0.2f + i * 0.05f)); t += 100 }
        assertEquals(1, s.entries)
        assertEquals(0, s.exits)
        // Walks back up = exit.
        for (i in 0..12) { s = engine.process(frame(t, 0.5f to 0.8f - i * 0.05f)); t += 100 }
        assertEquals(1, s.entries)
        assertEquals(1, s.exits)
        assertEquals(1, s.uniqueTracked)
    }

    @Test
    fun mixedObjects_areCountedPerClass() {
        val engine = PeopleCountingEngine()
        var s = CountingSnapshot.EMPTY
        for (i in 0 until 5) {
            s = engine.process(
                DetectionFrame(
                    listOf(
                        Detection(BoundingBox(0.1f, 0.1f, 0.3f, 0.8f), 0.9f, classId = 0), // person
                        Detection(BoundingBox(0.5f, 0.6f, 0.6f, 0.7f), 0.8f, classId = 46), // cup
                        Detection(BoundingBox(0.7f, 0.6f, 0.8f, 0.7f), 0.8f, classId = 46), // cup
                        Detection(BoundingBox(0.4f, 0.2f, 0.9f, 0.5f), 0.7f, classId = 72), // laptop
                    ),
                    480, 640, 30, i * 100L,
                ),
            )
        }
        assertEquals(4, s.visibleCount)
        assertEquals(mapOf(0 to 1, 46 to 2, 72 to 1), s.visibleByClass)
        assertEquals(4, s.uniqueTracked)
    }

    @Test
    fun reset_clearsEverything() {
        val engine = PeopleCountingEngine()
        for (i in 0 until 5) engine.process(frame(i * 100L, 0.5f to 0.5f))
        engine.reset()
        val s = engine.process(frame(600, 0.5f to 0.5f))
        assertEquals(0, s.visibleCount)
        assertEquals(0, s.uniqueTracked)
    }
}
