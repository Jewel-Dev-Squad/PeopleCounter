package com.hibee.peoplecounter

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.hibee.peoplecounter.detection.CocoLabels
import com.hibee.peoplecounter.detection.ModelOption
import com.hibee.peoplecounter.detection.TfLiteObjectDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Runs the real bundled models on a device/emulator:
 *   ./gradlew connectedDebugAndroidTest
 * one_person.jpg is a public-domain portrait (one person) from google-coral/test_data.
 */
@RunWith(AndroidJUnit4::class)
class ObjectDetectorInstrumentedTest {

    private val instrumentation = InstrumentationRegistry.getInstrumentation()

    private fun loadTestImage(size: Int): Bitmap {
        val raw = instrumentation.context.assets.open("one_person.jpg").use { BitmapFactory.decodeStream(it) }
        return Bitmap.createScaledBitmap(raw, size, size, true).copy(Bitmap.Config.ARGB_8888, false)
    }

    @Test
    fun bothModels_loadAndDetectExactlyOnePerson() {
        for (model in ModelOption.entries) {
            TfLiteObjectDetector.create(instrumentation.targetContext, model, numThreads = 2).use { detector ->
                val people = detector.detect(loadTestImage(model.inputSize), minScore = 0.5f, allowedClassIds = setOf(CocoLabels.PERSON))
                assertEquals("model=$model", 1, people.size)
                assertTrue(people[0].box.area > 0.3f) // the person fills most of the photo
            }
        }
    }

    @Test
    fun bothModels_recogniseACatWithAllClassesEnabled() {
        for (model in ModelOption.entries) {
            TfLiteObjectDetector.create(instrumentation.targetContext, model, numThreads = 2).use { detector ->
                val raw = instrumentation.context.assets.open("cat.jpg").use { BitmapFactory.decodeStream(it) }
                val img = Bitmap.createScaledBitmap(raw, model.inputSize, model.inputSize, true)
                    .copy(Bitmap.Config.ARGB_8888, false)
                val names = detector.detect(img, minScore = 0.4f, allowedClassIds = null)
                    .map { CocoLabels.nameFor(it.classId) }
                assertTrue("model=$model saw $names", "cat" in names)
            }
        }
    }

    @Test
    fun blankImage_detectsNobody() {
        val blank = Bitmap.createBitmap(320, 320, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.GRAY) }
        TfLiteObjectDetector.create(instrumentation.targetContext, ModelOption.BALANCED, 2).use { detector ->
            assertTrue(detector.detect(blank, minScore = 0.5f, allowedClassIds = null).isEmpty())
        }
    }

    @Test
    fun inferenceTime_isMeasuredNotAssumed() {
        TfLiteObjectDetector.create(instrumentation.targetContext, ModelOption.BALANCED, 4).use { detector ->
            val img = loadTestImage(320)
            detector.detect(img, 0.5f, null) // warm-up
            val runs = 10
            val start = System.nanoTime()
            repeat(runs) { detector.detect(img, 0.5f, null) }
            val avgMs = (System.nanoTime() - start) / 1e6 / runs
            println("EfficientDet-Lite0 average inference on this device: %.1f ms".format(avgMs))
            assertTrue(avgMs > 0)
        }
    }
}
