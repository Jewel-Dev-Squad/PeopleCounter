package com.hibee.peoplecounter.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.hibee.peoplecounter.detection.ModelOption
import com.hibee.peoplecounter.settings.DetectionMode
import com.hibee.peoplecounter.ui.components.CameraPreviewPlaceholder
import com.hibee.peoplecounter.ui.components.CenteredMessage
import com.hibee.peoplecounter.ui.components.ControlBar
import com.hibee.peoplecounter.ui.components.CountPanel
import com.hibee.peoplecounter.ui.components.CoverageCard
import com.hibee.peoplecounter.ui.components.DetectionOverlay
import com.hibee.peoplecounter.ui.components.StatusChip
import com.hibee.peoplecounter.ui.theme.Warning
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PeopleCounterScreen(
    viewModel: PeopleCounterViewModel,
    onOpenSettings: () -> Unit,
    onOpenPrivacy: () -> Unit,
) {
    val ui by viewModel.ui.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showExplanation by rememberSaveable { mutableStateOf(false) }
    var showPermissionRationale by remember { mutableStateOf(false) }
    // Android cannot tell "dialog dismissed" from "denied forever" directly. We only call it
    // permanent if the system previously allowed a rationale and now no longer does.
    var rationaleWasAllowed by rememberSaveable { mutableStateOf(false) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.onCameraPermissionRechecked(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED,
        )
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) {
            viewModel.startCounting()
        } else {
            val activity = context.findActivity()
            val canAskAgain = activity?.shouldShowRequestPermissionRationale(Manifest.permission.CAMERA) ?: false
            if (canAskAgain) rationaleWasAllowed = true
            viewModel.onCameraPermissionDenied(permanently = !canAskAgain && rationaleWasAllowed)
        }
    }

    val requestStart: () -> Unit = {
        when {
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED -> viewModel.startCounting()
            context.findActivity()?.shouldShowRequestPermissionRationale(Manifest.permission.CAMERA) == true -> {
                rationaleWasAllowed = true
                showPermissionRationale = true
            }
            else -> cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Object Detector", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                actions = {
                    IconButton(onClick = onOpenPrivacy) {
                        Icon(Icons.Filled.PrivacyTip, contentDescription = "Privacy and permissions")
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                },
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // ---- camera area (takes all remaining height) ----
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black),
            ) {
                if (ui.cameraActive) {
                    CameraPreview(
                        analyzer = viewModel.analyzer,
                        resolution = settings.analysisResolution,
                        onCameraError = viewModel::onCameraError,
                        onBackground = viewModel::onLeaveCameraScreen,
                        onForeground = viewModel::onReturnToCameraScreen,
                        modifier = Modifier.fillMaxSize(),
                    )
                    DetectionOverlay(
                        snapshot = ui.snapshot,
                        countingLine = settings.countingLineOrNull(),
                        showIds = settings.showTrackIds,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    CameraPreviewPlaceholder(Modifier.fillMaxSize()) {
                        if (ui.status == DetectionStatus.CAMERA_UNAVAILABLE) {
                            CenteredMessage("Camera Unavailable", ui.statusDetail)
                            if (ui.permissionPermanentlyDenied) {
                                Button(onClick = { context.openAppSettings() }) { Text("Open app settings") }
                            } else if (ui.cameraPermissionMissing) {
                                Button(onClick = requestStart) { Text("Grant camera permission") }
                            }
                        } else {
                            CenteredMessage(
                                "Press Start to open the rear camera",
                                ui.statusDetail ?: "All detection runs on this phone. No images are saved or uploaded.",
                            )
                        }
                    }
                }

                StatusChip(ui.status, Modifier.align(Alignment.TopStart).padding(10.dp))

                if (ui.cameraActive) {
                    PerformanceBadge(ui, Modifier.align(Alignment.TopEnd).padding(10.dp))
                }
                if (ui.status == DetectionStatus.PAUSED) {
                    CenteredMessage("Paused", "Detection is paused. Counts are kept.", Modifier.align(Alignment.Center))
                }
                SlowDeviceBanner(ui, onSwitch = viewModel::switchToFastModel, Modifier.align(Alignment.BottomCenter))
            }

            val objectsMode = settings.mode == DetectionMode.OBJECTS
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DetectionMode.entries.forEach { mode ->
                    FilterChip(
                        selected = settings.mode == mode,
                        onClick = { viewModel.updateSettings { it.copy(mode = mode) } },
                        label = { Text(mode.label) },
                    )
                }
            }

            CountPanel(
                title = if (objectsMode) "Objects in view" else "People visible now",
                visible = ui.snapshot.visibleCount,
                visibleByClass = ui.snapshot.visibleByClass,
                showBreakdown = objectsMode,
                noCategories = objectsMode && settings.enabledCategories.isEmpty(),
                uniqueTracked = ui.snapshot.uniqueTracked,
                entries = ui.snapshot.entries,
                exits = ui.snapshot.exits,
                lineEnabled = settings.lineCountingEnabled,
                onExplain = { showExplanation = true },
            )

            if (!objectsMode) CoverageCard(ui.coverage, ui.location, settings.useLocation)

            ControlBar(
                startLabel = if (settings.mode == DetectionMode.OBJECTS) "Start Detecting" else "Start Counting",
                status = ui.status,
                cameraActive = ui.cameraActive,
                onStart = requestStart,
                onPause = viewModel::pause,
                onResume = viewModel::resume,
                onStop = viewModel::stop,
                onReset = viewModel::resetCounts,
                modifier = Modifier.padding(bottom = 8.dp),
            )
        }
    }

    if (showExplanation) {
        AlertDialog(
            onDismissRequest = { showExplanation = false },
            confirmButton = { TextButton(onClick = { showExplanation = false }) { Text("Got it") } },
            title = { Text("How detection works") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        if (settings.mode == DetectionMode.OBJECTS) OBJECTS_EXPLANATION else COUNT_EXPLANATION,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            },
        )
    }

    if (showPermissionRationale) {
        AlertDialog(
            onDismissRequest = { showPermissionRationale = false },
            title = { Text("Camera access") },
            text = {
                Text(
                    "Object Detector uses the rear camera to recognise objects and people in real time. " +
                        "Frames are analysed in memory on this phone and immediately discarded. " +
                        "Nothing is recorded, saved or uploaded, and the app has no internet permission.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showPermissionRationale = false
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                }) { Text("Continue") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showPermissionRationale = false
                    viewModel.onCameraPermissionDenied(permanently = false)
                }) { Text("Not now") }
            },
        )
    }
}

@Composable
private fun PerformanceBadge(ui: UiState, modifier: Modifier = Modifier) {
    val p = ui.performance
    val modelName = when (ui.activeModel) {
        null -> if (ui.modelError != null) "model error" else "loading model…"
        else -> ui.activeModel.name.lowercase(Locale.US) + if (ui.usingFallbackModel) " (fallback)" else ""
    }
    Column(
        modifier
            .background(Color(0xCC0F1720), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.End,
    ) {
        Text(modelName, style = MaterialTheme.typography.labelSmall, color = Color.White)
        if (p.samples > 0) {
            Text(
                String.format(Locale.US, "%.0f ms · %.1f fps (measured)", p.averageInferenceMs, p.processedFps),
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFFCBD5E1),
            )
        }
        Text(
            "boxes: ${ui.snapshot.rawDetectionCount}",
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFFCBD5E1),
        )
    }
}

@Composable
private fun SlowDeviceBanner(ui: UiState, onSwitch: () -> Unit, modifier: Modifier = Modifier) {
    if (!ui.performance.isStruggling) return
    Row(
        modifier
            .padding(10.dp)
            .fillMaxWidth()
            .background(Color(0xE63A2C0B), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = if (ui.activeModel == ModelOption.BALANCED) {
                "This phone is processing slowly. Boxes may lag behind moving objects."
            } else {
                "This phone is processing slowly. Try fewer threads or a lower detection rate in Settings."
            },
            style = MaterialTheme.typography.bodySmall,
            color = Warning,
            modifier = Modifier.weight(1f),
        )
        if (ui.activeModel == ModelOption.BALANCED) {
            Spacer(Modifier.size(8.dp))
            TextButton(onClick = onSwitch) { Text("Use Fast model") }
        }
    }
}

private fun Context.findActivity(): Activity? {
    var ctx: Context? = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}

private fun Context.openAppSettings() {
    startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
    )
}

private const val OBJECTS_EXPLANATION = """Objects in view – everything the model currently recognises and has tracked for a few frames, with a breakdown per object type below the number.

What it can recognise – 80 common object types (the COCO set): people, vehicles, animals, furniture, electronics, kitchen items, food, sports gear, bags and a few household items. You can narrow this down by category in Settings.

What it cannot recognise – anything outside those 80 types, for example doors, windows, trees, walls, pens, shoes, fans, buildings or rickshaws. These are ignored or, occasionally, given a wrong label.

Box colours – each object type has its own colour. A solid box with a label is counted; a thin dashed box has been seen for less than 3 frames and is not counted yet.

Tracked total (est.) – how many different objects have been tracked since you started or reset. Something hidden for more than about 1.5 seconds, or that leaves and comes back, is counted again.

Limits – at most 20–25 objects per frame. Small, distant, unusual-looking or poorly lit objects are often missed, and similar-looking things can be confused (for example cup and vase). Accuracy is never perfect."""

private const val COUNT_EXPLANATION = """Visible now – people the model currently detects in the camera view and has tracked for a few frames. Short gaps (under half a second) are bridged so the number does not flicker.

Tracked total (est.) – how many different people have been tracked since you started or reset. This is an estimate: someone who is hidden for more than about 1.5 seconds, or who leaves and comes back, gets a new ID and is counted again. People who were never detected are not counted.

In / Out – optional. People whose tracked position crosses the dashed blue line. Enable it in Settings.

What is NOT counted – anyone the camera cannot see: people behind you, behind walls, crowds or obstacles, too far away or too small in the image, or in poor light. The app does not know how far away people are, so it cannot say whether they are within 100 m.

Accuracy is never perfect. Expect misses with occlusion, unusual poses, low light and very distant people, and occasional false detections."""
