package com.hibee.peoplecounter.settings

import com.hibee.peoplecounter.counting.CountingLine
import com.hibee.peoplecounter.counting.LineOrientation
import com.hibee.peoplecounter.detection.Category
import com.hibee.peoplecounter.detection.CocoLabels
import com.hibee.peoplecounter.detection.ModelOption

/** What the camera looks for. */
enum class DetectionMode(val label: String) {
    /** All 80 COCO object types (optionally narrowed by category). */
    OBJECTS("All objects"),

    /** Only people, with the radius/coverage information. */
    PEOPLE("People counter"),
}

/** Camera frame size requested for analysis (the model input is fixed per model). */
enum class AnalysisResolution(val width: Int, val height: Int, val label: String) {
    LOW(640, 480, "640 × 480 (faster)"),
    HIGH(1280, 960, "1280 × 960 (sharper source image)"),
}

/** User-adjustable options. Pure data; persisted by [SettingsRepository]. */
data class AppSettings(
    val mode: DetectionMode = DetectionMode.OBJECTS,
    /** Categories shown in OBJECTS mode. */
    val enabledCategories: Set<Category> = Category.entries.toSet(),
    val model: ModelOption = ModelOption.BALANCED,
    val analysisResolution: AnalysisResolution = AnalysisResolution.LOW,
    /** 0 = as fast as the device can go. */
    val maxDetectionsPerSecond: Int = 10,
    val numThreads: Int = 4,
    val confidenceThreshold: Float = 0.5f,
    val targetRadiusMeters: Int = 100,
    val showTrackIds: Boolean = true,
    val lineCountingEnabled: Boolean = false,
    val lineOrientation: LineOrientation = LineOrientation.HORIZONTAL,
    val linePosition: Float = 0.5f,
    val invertLineDirection: Boolean = false,
    val useLocation: Boolean = false,
) {
    /** Class ids passed to the decoder; null = every known class. */
    fun allowedClassIds(): Set<Int>? = when (mode) {
        DetectionMode.PEOPLE -> setOf(CocoLabels.PERSON)
        DetectionMode.OBJECTS ->
            if (enabledCategories.containsAll(Category.entries)) null
            else CocoLabels.classIdsIn(enabledCategories)
    }

    fun countingLineOrNull(): CountingLine? =
        if (!lineCountingEnabled) null
        else CountingLine(
            orientation = lineOrientation,
            position = linePosition.coerceIn(0.1f, 0.9f),
            invertDirection = invertLineDirection,
        )

    companion object {
        val DETECTION_RATE_OPTIONS = listOf(5, 10, 15, 0)
        val THREAD_OPTIONS = listOf(1, 2, 4)
    }
}
