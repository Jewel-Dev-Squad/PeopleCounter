package com.hibee.peoplecounter.ui

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.hibee.peoplecounter.counting.LineOrientation
import com.hibee.peoplecounter.detection.Category
import com.hibee.peoplecounter.detection.CocoLabels
import com.hibee.peoplecounter.detection.ModelOption
import com.hibee.peoplecounter.settings.AnalysisResolution
import com.hibee.peoplecounter.settings.AppSettings
import com.hibee.peoplecounter.settings.DetectionMode
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(viewModel: PeopleCounterViewModel, onBack: () -> Unit) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    BackHandler(onBack = onBack)

    val locationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { result -> viewModel.onLocationPermissionResult(result.values.any { it }) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Section("What to detect")
            DetectionMode.entries.forEach { m ->
                RadioRow(
                    selected = s.mode == m,
                    title = m.label,
                    subtitle = when (m) {
                        DetectionMode.OBJECTS -> "80 common object types, with a count for each."
                        DetectionMode.PEOPLE -> "People only, with the radius and coverage information."
                    },
                    onClick = { viewModel.updateSettings { it.copy(mode = m) } },
                )
            }
            if (s.mode == DetectionMode.OBJECTS) {
                Text(
                    "Object categories (${s.enabledCategories.size} of ${Category.entries.size})",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 8.dp),
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Category.entries.forEach { c ->
                        FilterChip(
                            selected = c in s.enabledCategories,
                            onClick = {
                                viewModel.updateSettings {
                                    it.copy(
                                        enabledCategories = if (c in it.enabledCategories) {
                                            it.enabledCategories - c
                                        } else {
                                            it.enabledCategories + c
                                        },
                                    )
                                }
                            },
                            label = { Text(c.displayName) },
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        viewModel.updateSettings { it.copy(enabledCategories = Category.entries.toSet()) }
                    }) { Text("Select all") }
                    TextButton(onClick = {
                        viewModel.updateSettings { it.copy(enabledCategories = emptySet()) }
                    }) { Text("Clear") }
                }
                if (s.enabledCategories.isEmpty()) {
                    Text(
                        "No category selected – nothing will be detected.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                } else if (s.enabledCategories.size < Category.entries.size) {
                    Hint(
                        "Includes: " + s.enabledCategories.sortedBy { it.ordinal }
                            .flatMap { CocoLabels.namesIn(it) }.joinToString(", "),
                    )
                }
            }

            HorizontalDivider()
            Section("Detection model")
            ModelOption.entries.forEach { m ->
                RadioRow(
                    selected = s.model == m,
                    title = m.displayName,
                    subtitle = m.description,
                    onClick = { viewModel.updateSettings { it.copy(model = m) } },
                )
            }

            Section("Camera analysis resolution")
            AnalysisResolution.entries.forEach { r ->
                RadioRow(
                    selected = s.analysisResolution == r,
                    title = r.label,
                    subtitle = null,
                    onClick = { viewModel.updateSettings { it.copy(analysisResolution = r) } },
                )
            }
            Hint(
                "The model always sees a ${s.model.inputSize}×${s.model.inputSize} image. " +
                    "A higher camera resolution costs more conversion time and rarely helps.",
            )

            Section("Maximum detection rate")
            ChipRow(
                options = AppSettings.DETECTION_RATE_OPTIONS,
                selected = s.maxDetectionsPerSecond,
                label = { if (it == 0) "Max" else "$it / s" },
                onSelect = { v -> viewModel.updateSettings { it.copy(maxDetectionsPerSecond = v) } },
            )
            Hint("Lower rates save battery. The real rate is measured and shown on the camera view.")

            Section("CPU threads")
            ChipRow(
                options = AppSettings.THREAD_OPTIONS,
                selected = s.numThreads,
                label = { "$it" },
                onSelect = { v -> viewModel.updateSettings { it.copy(numThreads = v) } },
            )

            Section("Confidence threshold: ${(s.confidenceThreshold * 100).roundToInt()}%")
            var conf by remember(s.confidenceThreshold) { mutableFloatStateOf(s.confidenceThreshold) }
            Slider(
                value = conf,
                onValueChange = { conf = it },
                onValueChangeFinished = { viewModel.updateSettings { it.copy(confidenceThreshold = conf) } },
                valueRange = 0.3f..0.8f,
                steps = 9,
            )
            Hint("Lower = finds more distant or partly hidden objects but more wrong boxes. Higher = fewer wrong boxes, more misses.")

            HorizontalDivider()
            Section("People counter: target radius")
            ChipRow(
                options = listOf(25, 50, 100),
                selected = s.targetRadiusMeters,
                label = { "$it m" },
                onSelect = { v -> viewModel.updateSettings { it.copy(targetRadiusMeters = v) } },
            )
            Hint(
                "A single phone camera cannot observe a whole radius, so the app always reports " +
                    "\"visible people only\" until validated sensors covering the full area are added.",
            )

            SwitchRow(
                title = "Show my location",
                subtitle = "Optional. Shows where the radius is centred. GPS cannot detect other people.",
                checked = s.useLocation,
                onChange = { enabled ->
                    if (enabled && !viewModel.hasLocationPermission()) {
                        locationLauncher.launch(
                            arrayOf(
                                Manifest.permission.ACCESS_COARSE_LOCATION,
                                Manifest.permission.ACCESS_FINE_LOCATION,
                            ),
                        )
                    } else {
                        viewModel.setUseLocation(enabled)
                    }
                },
            )

            HorizontalDivider()
            Section("Entry / exit line")
            SwitchRow(
                title = "Count line crossings",
                subtitle = "Counts tracked objects (in People mode: people) crossing a virtual line in the view.",
                checked = s.lineCountingEnabled,
                onChange = { v -> viewModel.updateSettings { it.copy(lineCountingEnabled = v) } },
            )
            if (s.lineCountingEnabled) {
                ChipRow(
                    options = LineOrientation.entries.toList(),
                    selected = s.lineOrientation,
                    label = { if (it == LineOrientation.HORIZONTAL) "Horizontal" else "Vertical" },
                    onSelect = { v -> viewModel.updateSettings { it.copy(lineOrientation = v) } },
                )
                Text(
                    String.format(Locale.US, "Line position: %.0f%%", s.linePosition * 100),
                    style = MaterialTheme.typography.bodyMedium,
                )
                var pos by remember(s.linePosition) { mutableFloatStateOf(s.linePosition) }
                Slider(
                    value = pos,
                    onValueChange = { pos = it },
                    onValueChangeFinished = { viewModel.updateSettings { it.copy(linePosition = pos) } },
                    valueRange = 0.1f..0.9f,
                )
                SwitchRow(
                    title = "Invert direction",
                    subtitle = if (s.lineOrientation == LineOrientation.HORIZONTAL) {
                        "Off: top → bottom = In. On: bottom → top = In."
                    } else {
                        "Off: left → right = In. On: right → left = In."
                    },
                    checked = s.invertLineDirection,
                    onChange = { v -> viewModel.updateSettings { it.copy(invertLineDirection = v) } },
                )
            }

            HorizontalDivider()
            Section("Display")
            SwitchRow(
                title = "Show tracking IDs",
                subtitle = "Temporary numbers that exist only while the app is counting.",
                checked = s.showTrackIds,
                onChange = { v -> viewModel.updateSettings { it.copy(showTrackIds = v) } },
            )
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 12.dp),
    )
}

@Composable
private fun Hint(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun RadioRow(selected: Boolean, title: String, subtitle: String?, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .selectable(selected = selected, onClick = onClick, role = Role.RadioButton)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Column(Modifier.padding(start = 8.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) Hint(subtitle)
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) Hint(subtitle)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun <T> ChipRow(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { option ->
            FilterChip(
                selected = option == selected,
                onClick = { onSelect(option) },
                label = { Text(label(option)) },
            )
        }
    }
}
