package com.hibee.peoplecounter.tracking

import com.hibee.peoplecounter.detection.BoundingBox
import com.hibee.peoplecounter.detection.Detection
import kotlin.math.hypot

/**
 * Tuning knobs for [ObjectTracker]. Times are in milliseconds so behaviour does
 * not change when the phone processes more or fewer frames per second.
 */
data class TrackerConfig(
    /** Minimum IoU between a predicted track box and a detection to match them. */
    val minIou: Float = 0.2f,
    /**
     * Fallback for fast motion / low frame rate: a detection whose centre is within
     * this fraction of the track box diagonal can still match even with low IoU.
     */
    val maxCenterDistanceRatio: Float = 0.6f,
    /** Consecutive matched frames required before a track is "confirmed" (counted). */
    val minHitsToConfirm: Int = 3,
    /** A confirmed track survives this long without detections (occlusion handling). */
    val maxLostMs: Long = 1_500,
    /** An unconfirmed track is dropped after this long without detections. */
    val maxTentativeLostMs: Long = 300,
    /** Box smoothing: weight of the new detection (1 = no smoothing). */
    val boxSmoothing: Float = 0.7f,
    /** Velocity smoothing: weight of the newest velocity sample. */
    val velocitySmoothing: Float = 0.5f,
    /** Upper bound for motion prediction, to avoid tracks flying away. */
    val maxPredictionMs: Long = 500,
)

/** Immutable view of a track handed to the counting engine and the UI. */
data class TrackSnapshot(
    val id: Int,
    /** COCO class index; a track never changes class. */
    val classId: Int,
    val box: BoundingBox,
    val score: Float,
    val confirmed: Boolean,
    /** True when the track was matched to a detection in the most recent frame. */
    val matchedThisFrame: Boolean,
    val lastSeenMs: Long,
    val firstSeenMs: Long,
)

/**
 * Lightweight multi-object tracker (IoU + centre distance, greedy assignment,
 * constant-velocity prediction). It gives each object a temporary numeric ID
 * that stays stable while it remains visible, so the same object is not
 * counted again in every frame. Detections only match tracks of the same class.
 *
 * Deliberately simple: no appearance features / re-identification, so an object
 * that is fully hidden for longer than [TrackerConfig.maxLostMs] or leaves and
 * re-enters the view will receive a new ID. Pure Kotlin; unit-tested on the JVM.
 */
class ObjectTracker(private val config: TrackerConfig = TrackerConfig()) {

    private class Track(
        val id: Int,
        val classId: Int,
        var box: BoundingBox,
        var score: Float,
        val firstSeenMs: Long,
        var lastSeenMs: Long,
    ) {
        var hits = 1
        var confirmed = false
        var matchedThisFrame = true
        var vx = 0f // normalized units per ms
        var vy = 0f
    }

    private val tracks = mutableListOf<Track>()
    private var nextId = 1
    private var lastUpdateMs: Long? = null

    /** Called whenever a track becomes confirmed for the first time. */
    var onTrackConfirmed: ((Int) -> Unit)? = null

    /** Called whenever a track is permanently removed. */
    var onTrackRemoved: ((Int) -> Unit)? = null

    val activeTrackCount: Int get() = tracks.size

    fun update(detections: List<Detection>, timestampMs: Long): List<TrackSnapshot> {
        lastUpdateMs = timestampMs

        // 1. Predict where each track should be now.
        val predicted = tracks.map { t ->
            val dt = (timestampMs - t.lastSeenMs).coerceIn(0, config.maxPredictionMs).toFloat()
            t.box.translated(t.vx * dt, t.vy * dt)
        }

        // 2. Score every (track, detection) pair and assign greedily, best first.
        data class Candidate(val track: Int, val det: Int, val score: Float)
        val candidates = ArrayList<Candidate>()
        for (ti in tracks.indices) {
            val p = predicted[ti]
            val diag = hypot(p.width, p.height).coerceAtLeast(1e-4f)
            for (di in detections.indices) {
                if (detections[di].classId != tracks[ti].classId) continue // never mix classes
                val d = detections[di].box
                val iou = p.iou(d)
                if (iou >= config.minIou) {
                    candidates += Candidate(ti, di, 1f + iou) // IoU matches always win
                } else {
                    val dist = hypot(p.centerX - d.centerX, p.centerY - d.centerY) / diag
                    val sizeRatio = d.area / p.area.coerceAtLeast(1e-6f)
                    if (dist <= config.maxCenterDistanceRatio && sizeRatio in 0.33f..3f) {
                        candidates += Candidate(ti, di, 1f - dist)
                    }
                }
            }
        }
        candidates.sortByDescending { it.score }

        val trackMatched = BooleanArray(tracks.size)
        val detMatched = BooleanArray(detections.size)
        for (c in candidates) {
            if (trackMatched[c.track] || detMatched[c.det]) continue
            trackMatched[c.track] = true
            detMatched[c.det] = true
            applyMatch(tracks[c.track], detections[c.det], timestampMs)
        }

        // 3. Age out unmatched tracks.
        val iterator = tracks.iterator()
        var index = 0
        while (iterator.hasNext()) {
            val t = iterator.next()
            if (!trackMatched[index]) {
                t.matchedThisFrame = false
                val lostFor = timestampMs - t.lastSeenMs
                val limit = if (t.confirmed) config.maxLostMs else config.maxTentativeLostMs
                if (lostFor > limit) {
                    iterator.remove()
                    onTrackRemoved?.invoke(t.id)
                }
            }
            index++
        }

        // 4. Start new tentative tracks for unmatched detections.
        for (di in detections.indices) {
            if (detMatched[di]) continue
            val d = detections[di]
            tracks += Track(nextId++, d.classId, d.box, d.score, timestampMs, timestampMs).also {
                if (config.minHitsToConfirm <= 1) confirm(it)
            }
        }

        return snapshot()
    }

    private fun applyMatch(t: Track, d: Detection, now: Long) {
        val dt = (now - t.lastSeenMs).toFloat()
        if (dt > 0f) {
            val a = config.velocitySmoothing
            val newVx = (d.box.centerX - t.box.centerX) / dt
            val newVy = (d.box.centerY - t.box.centerY) / dt
            t.vx = t.vx + (newVx - t.vx) * a
            t.vy = t.vy + (newVy - t.vy) * a
        }
        t.box = t.box.lerp(d.box, config.boxSmoothing)
        t.score = d.score
        t.lastSeenMs = now
        t.matchedThisFrame = true
        t.hits++
        if (!t.confirmed && t.hits >= config.minHitsToConfirm) confirm(t)
    }

    private fun confirm(t: Track) {
        t.confirmed = true
        onTrackConfirmed?.invoke(t.id)
    }

    /**
     * Shifts all track timestamps forward after a pause so that people who are
     * still in the same place keep their IDs instead of being counted again.
     */
    fun compensatePause(pausedForMs: Long) {
        if (pausedForMs <= 0) return
        for (t in tracks) {
            t.lastSeenMs += pausedForMs
            t.vx = 0f
            t.vy = 0f
        }
        lastUpdateMs = lastUpdateMs?.plus(pausedForMs)
    }

    fun snapshot(): List<TrackSnapshot> = tracks.map {
        TrackSnapshot(
            id = it.id,
            classId = it.classId,
            box = it.box,
            score = it.score,
            confirmed = it.confirmed,
            matchedThisFrame = it.matchedThisFrame,
            lastSeenMs = it.lastSeenMs,
            firstSeenMs = it.firstSeenMs,
        )
    }

    /** Removes all tracks. IDs keep increasing so they never collide with old ones. */
    fun clear() {
        tracks.clear()
        lastUpdateMs = null
    }

    /** Full reset including the ID counter. */
    fun reset() {
        clear()
        nextId = 1
    }
}
