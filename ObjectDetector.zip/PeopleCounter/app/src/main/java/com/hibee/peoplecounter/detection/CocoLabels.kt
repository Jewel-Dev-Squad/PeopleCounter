package com.hibee.peoplecounter.detection

/** Groups used by the category filter in Settings. */
enum class Category(val displayName: String) {
    PEOPLE("People"),
    VEHICLES("Vehicles"),
    OUTDOOR("Street & outdoor"),
    ANIMALS("Animals"),
    ACCESSORIES("Bags & accessories"),
    SPORTS("Sports"),
    KITCHEN("Kitchen"),
    FOOD("Food"),
    FURNITURE("Furniture"),
    ELECTRONICS("Electronics"),
    APPLIANCES("Appliances"),
    HOUSEHOLD("Household items"),
}

data class Label(val name: String, val category: Category)

/**
 * COCO labels exactly as the bundled models emit them: class index 0..89 in the
 * original 91-id COCO space minus one, with 10 unused ("n/a") slots.
 *
 * Verified by running both bundled models with the LiteRT Python runtime:
 * 0 = person, 5 = bus, 15 = bird, 16 = cat, 17 = dog, 36 = sports ball,
 * 37 = kite, 54 = orange (see tools/verify_labels.py).
 */
object CocoLabels {

    const val PERSON = 0

    private val TABLE: Array<Label?> = arrayOf(
        Label("person", Category.PEOPLE), // 0
        Label("bicycle", Category.VEHICLES), // 1
        Label("car", Category.VEHICLES), // 2
        Label("motorcycle", Category.VEHICLES), // 3
        Label("airplane", Category.VEHICLES), // 4
        Label("bus", Category.VEHICLES), // 5
        Label("train", Category.VEHICLES), // 6
        Label("truck", Category.VEHICLES), // 7
        Label("boat", Category.VEHICLES), // 8
        Label("traffic light", Category.OUTDOOR), // 9
        Label("fire hydrant", Category.OUTDOOR), // 10
        null, // 11 unused
        Label("stop sign", Category.OUTDOOR), // 12
        Label("parking meter", Category.OUTDOOR), // 13
        Label("bench", Category.OUTDOOR), // 14
        Label("bird", Category.ANIMALS), // 15
        Label("cat", Category.ANIMALS), // 16
        Label("dog", Category.ANIMALS), // 17
        Label("horse", Category.ANIMALS), // 18
        Label("sheep", Category.ANIMALS), // 19
        Label("cow", Category.ANIMALS), // 20
        Label("elephant", Category.ANIMALS), // 21
        Label("bear", Category.ANIMALS), // 22
        Label("zebra", Category.ANIMALS), // 23
        Label("giraffe", Category.ANIMALS), // 24
        null, // 25 unused
        Label("backpack", Category.ACCESSORIES), // 26
        Label("umbrella", Category.ACCESSORIES), // 27
        null, // 28 unused
        null, // 29 unused
        Label("handbag", Category.ACCESSORIES), // 30
        Label("tie", Category.ACCESSORIES), // 31
        Label("suitcase", Category.ACCESSORIES), // 32
        Label("frisbee", Category.SPORTS), // 33
        Label("skis", Category.SPORTS), // 34
        Label("snowboard", Category.SPORTS), // 35
        Label("sports ball", Category.SPORTS), // 36
        Label("kite", Category.SPORTS), // 37
        Label("baseball bat", Category.SPORTS), // 38
        Label("baseball glove", Category.SPORTS), // 39
        Label("skateboard", Category.SPORTS), // 40
        Label("surfboard", Category.SPORTS), // 41
        Label("tennis racket", Category.SPORTS), // 42
        Label("bottle", Category.KITCHEN), // 43
        null, // 44 unused
        Label("wine glass", Category.KITCHEN), // 45
        Label("cup", Category.KITCHEN), // 46
        Label("fork", Category.KITCHEN), // 47
        Label("knife", Category.KITCHEN), // 48
        Label("spoon", Category.KITCHEN), // 49
        Label("bowl", Category.KITCHEN), // 50
        Label("banana", Category.FOOD), // 51
        Label("apple", Category.FOOD), // 52
        Label("sandwich", Category.FOOD), // 53
        Label("orange", Category.FOOD), // 54
        Label("broccoli", Category.FOOD), // 55
        Label("carrot", Category.FOOD), // 56
        Label("hot dog", Category.FOOD), // 57
        Label("pizza", Category.FOOD), // 58
        Label("donut", Category.FOOD), // 59
        Label("cake", Category.FOOD), // 60
        Label("chair", Category.FURNITURE), // 61
        Label("couch", Category.FURNITURE), // 62
        Label("potted plant", Category.FURNITURE), // 63
        Label("bed", Category.FURNITURE), // 64
        null, // 65 unused
        Label("dining table", Category.FURNITURE), // 66
        null, // 67 unused
        null, // 68 unused
        Label("toilet", Category.FURNITURE), // 69
        null, // 70 unused
        Label("tv", Category.ELECTRONICS), // 71
        Label("laptop", Category.ELECTRONICS), // 72
        Label("mouse", Category.ELECTRONICS), // 73
        Label("remote", Category.ELECTRONICS), // 74
        Label("keyboard", Category.ELECTRONICS), // 75
        Label("cell phone", Category.ELECTRONICS), // 76
        Label("microwave", Category.APPLIANCES), // 77
        Label("oven", Category.APPLIANCES), // 78
        Label("toaster", Category.APPLIANCES), // 79
        Label("sink", Category.APPLIANCES), // 80
        Label("refrigerator", Category.APPLIANCES), // 81
        null, // 82 unused
        Label("book", Category.HOUSEHOLD), // 83
        Label("clock", Category.HOUSEHOLD), // 84
        Label("vase", Category.HOUSEHOLD), // 85
        Label("scissors", Category.HOUSEHOLD), // 86
        Label("teddy bear", Category.HOUSEHOLD), // 87
        Label("hair drier", Category.HOUSEHOLD), // 88
        Label("toothbrush", Category.HOUSEHOLD), // 89
    )

    /** Number of real object classes (80). */
    val classCount: Int = TABLE.count { it != null }

    fun labelFor(classId: Int): Label? = TABLE.getOrNull(classId)

    fun nameFor(classId: Int): String = labelFor(classId)?.name ?: "object $classId"

    /** All valid class ids belonging to [categories]. */
    fun classIdsIn(categories: Set<Category>): Set<Int> =
        TABLE.indices.filter { i -> TABLE[i]?.category?.let { it in categories } == true }.toSet()

    fun namesIn(category: Category): List<String> =
        TABLE.filterNotNull().filter { it.category == category }.map { it.name }
}
