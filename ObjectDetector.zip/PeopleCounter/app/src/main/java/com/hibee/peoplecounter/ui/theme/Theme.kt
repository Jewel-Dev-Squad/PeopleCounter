package com.hibee.peoplecounter.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Detected = Color(0xFF4ADE80)
val Tentative = Color(0xFFFACC15)
val Warning = Color(0xFFFBBF24)
val ErrorRed = Color(0xFFF87171)
val CountLine = Color(0xFF38BDF8)

/** Bright, distinct box colours; black label text stays readable on all of them. */
private val ClassPalette = listOf(
    Color(0xFF4ADE80), // green (person)
    Color(0xFFF472B6), // pink
    Color(0xFF60A5FA), // blue
    Color(0xFFFBBF24), // amber
    Color(0xFFA78BFA), // violet
    Color(0xFF2DD4BF), // teal
    Color(0xFFFB923C), // orange
    Color(0xFFA3E635), // lime
    Color(0xFF22D3EE), // cyan
    Color(0xFFF87171), // red
    Color(0xFFE879F9), // fuchsia
    Color(0xFFFDE047), // yellow
    Color(0xFFFCA5A5), // rose
)

/**
 * Stable colour for a COCO class id. Person is always green; other classes use
 * the remaining 12 colours, so no other class shares the person colour.
 */
fun classColor(classId: Int): Color =
    if (classId == 0) ClassPalette[0]
    else ClassPalette[1 + Math.floorMod(classId, ClassPalette.size - 1)]

private val Colors = darkColorScheme(
    primary = Color(0xFF4ADE80),
    onPrimary = Color(0xFF052E16),
    secondary = Color(0xFF38BDF8),
    onSecondary = Color(0xFF082F49),
    background = Color(0xFF0F1720),
    onBackground = Color(0xFFE5E7EB),
    surface = Color(0xFF16212D),
    onSurface = Color(0xFFE5E7EB),
    surfaceVariant = Color(0xFF1F2D3B),
    onSurfaceVariant = Color(0xFFB6C2CF),
    error = ErrorRed,
)

/** A camera app reads best in a dark theme, so the scheme is fixed. */
@Composable
fun PeopleCounterTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
