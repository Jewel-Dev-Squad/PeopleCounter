package com.hibee.peoplecounter.detection

/**
 * Converts the raw outputs of a TFLite_Detection_PostProcess style model
 * (boxes, classes, scores, count) into [Detection]s.
 *
 * Both bundled models (EfficientDet-Lite0 and SSD MobileNet V2, COCO) use this
 * layout; their tensor order and class indices (see [CocoLabels]) were verified
 * by running them with the LiteRT Python runtime (tools/verify_labels.py).
 *
 * Pure Kotlin – no Android dependencies – so it is unit-tested on the JVM.
 */
object DetectionDecoder {

    /**
     * @param boxes N x 4 array of [ymin, xmin, ymax, xmax] in normalized coordinates
     * @param classes N class indices (as floats, as emitted by the model)
     * @param scores N confidence scores in [0, 1]
     * @param count number of valid entries reported by the model
     * @param allowedClassIds classes to keep; null keeps every known COCO class
     * @param minScore detections below this confidence are dropped
     * @param nmsIouThreshold extra non-max suppression between boxes of the same class
     * @param minBoxArea drops tiny boxes (normalized area) that are usually noise
     */
    fun decode(
        boxes: Array<FloatArray>,
        classes: FloatArray,
        scores: FloatArray,
        count: Int,
        allowedClassIds: Set<Int>? = setOf(CocoLabels.PERSON),
        minScore: Float = 0.5f,
        nmsIouThreshold: Float = 0.6f,
        minBoxArea: Float = 0.0004f,
    ): List<Detection> {
        val n = minOf(count.coerceAtLeast(0), boxes.size, classes.size, scores.size)
        val kept = ArrayList<Detection>(n)
        for (i in 0 until n) {
            val score = scores[i]
            if (score.isNaN() || score < minScore) continue
            val cls = classes[i]
            if (cls.isNaN()) continue
            val classId = Math.round(cls)
            if (allowedClassIds != null) {
                if (classId !in allowedClassIds) continue
            } else if (CocoLabels.labelFor(classId) == null) {
                continue // unused "n/a" slot or out of range
            }
            val b = boxes[i]
            if (b.size < 4) continue
            val box = BoundingBox(left = b[1], top = b[0], right = b[3], bottom = b[2]).clamped()
            if (!box.isValid() || box.area < minBoxArea) continue
            kept += Detection(box, score, classId)
        }
        return nonMaxSuppression(kept, nmsIouThreshold)
    }

    /**
     * Greedy NMS per class: keeps the highest-scoring box among heavily
     * overlapping boxes of the same class (a person holding a cup keeps both).
     */
    fun nonMaxSuppression(detections: List<Detection>, iouThreshold: Float): List<Detection> {
        if (detections.size < 2) return detections
        val sorted = detections.sortedByDescending { it.score }
        val kept = ArrayList<Detection>(sorted.size)
        for (candidate in sorted) {
            if (kept.none { it.classId == candidate.classId && it.box.iou(candidate.box) > iouThreshold }) {
                kept += candidate
            }
        }
        return kept
    }
}
