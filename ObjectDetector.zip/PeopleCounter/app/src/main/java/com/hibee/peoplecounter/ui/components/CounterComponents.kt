package com.hibee.peoplecounter.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hibee.peoplecounter.coverage.CoverageLevel
import com.hibee.peoplecounter.detection.CocoLabels
import com.hibee.peoplecounter.coverage.CoverageStatus
import com.hibee.peoplecounter.location.LocationState
import com.hibee.peoplecounter.ui.DetectionStatus
import com.hibee.peoplecounter.ui.theme.Detected
import com.hibee.peoplecounter.ui.theme.ErrorRed
import com.hibee.peoplecounter.ui.theme.Warning
import com.hibee.peoplecounter.ui.theme.classColor
import java.util.Locale

@Composable
fun StatusChip(status: DetectionStatus, modifier: Modifier = Modifier) {
    val color = when (status) {
        DetectionStatus.READY -> Color(0xFF94A3B8)
        DetectionStatus.DETECTING -> Detected
        DetectionStatus.PAUSED -> Warning
        DetectionStatus.CAMERA_UNAVAILABLE -> ErrorRed
    }
    Row(
        modifier = modifier
            .background(Color(0xCC0F1720), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .semantics { contentDescription = "Status: ${status.label}" },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Spacer(Modifier.size(8.dp).background(color, CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(status.label, color = Color.White, style = MaterialTheme.typography.labelLarge)
    }
}

/**
 * Main numbers. [visibleByClass] is shown as a scrollable row of
 * "● laptop 1" chips when [showBreakdown] is true (All objects mode).
 */
@Composable
fun CountPanel(
    title: String,
    visible: Int,
    visibleByClass: Map<Int, Int>,
    showBreakdown: Boolean,
    uniqueTracked: Int,
    noCategories: Boolean = false,
    entries: Int,
    exits: Int,
    lineEnabled: Boolean,
    onExplain: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(modifier = modifier.fillMaxWidth(), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = visible.toString(),
                        fontSize = if (showBreakdown) 48.sp else 64.sp,
                        lineHeight = if (showBreakdown) 50.sp else 66.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.semantics { contentDescription = "$visible $title" },
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    SmallStat("Tracked total (est.)", uniqueTracked.toString())
                    if (lineEnabled) {
                        Spacer(Modifier.size(6.dp))
                        SmallStat("In / Out", "$entries / $exits")
                    }
                    TextButton(onClick = onExplain) {
                        Icon(Icons.Filled.Info, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("What do these mean?", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            if (showBreakdown) {
                val rows = visibleByClass.entries
                    .sortedWith(compareByDescending<Map.Entry<Int, Int>> { it.value }.thenBy { CocoLabels.nameFor(it.key) })
                if (noCategories) {
                    Text(
                        "No object categories selected – open Settings to choose what to detect.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                } else if (rows.isEmpty()) {
                    Text(
                        "Nothing recognised yet. Point the camera at everyday objects.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(rows.size, key = { rows[it].key }) { i ->
                            val (classId, count) = rows[i].key to rows[i].value
                            ClassChip(classId, count)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ClassChip(classId: Int, count: Int) {
    Row(
        Modifier
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Spacer(Modifier.size(10.dp).background(classColor(classId), CircleShape))
        Spacer(Modifier.width(6.dp))
        Text(
            "${CocoLabels.nameFor(classId)} $count",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

@Composable
private fun SmallStat(label: String, value: String) {
    Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
}

/** Radius + honest coverage indicator. Never shows a fabricated full-radius count. */
@Composable
fun CoverageCard(
    coverage: CoverageStatus,
    location: LocationState,
    locationEnabled: Boolean,
    modifier: Modifier = Modifier,
) {
    val full = coverage.level == CoverageLevel.FULL_VALIDATED
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (full) Color(0xFF14321F) else Color(0xFF3A2C0B),
        ),
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (full) Icons.Filled.Info else Icons.Filled.Warning,
                    contentDescription = null,
                    tint = if (full) Detected else Warning,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "Selected radius: ${coverage.targetRadiusMeters} m",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.weight(1f))
                Text(
                    when (coverage.level) {
                        CoverageLevel.VISIBLE_ONLY -> "VISIBLE ONLY"
                        CoverageLevel.PARTIAL_VALIDATED -> "PARTIAL"
                        CoverageLevel.FULL_VALIDATED -> "FULL AREA"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = if (full) Detected else Warning,
                    fontWeight = FontWeight.Bold,
                )
            }
            Spacer(Modifier.size(4.dp))
            Text(coverage.message, style = MaterialTheme.typography.bodySmall)
            if (locationEnabled) {
                Spacer(Modifier.size(4.dp))
                Text(
                    text = locationText(location),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

private fun locationText(state: LocationState): String = when (state) {
    LocationState.Disabled -> "Location: off"
    LocationState.PermissionMissing -> "Location: permission not granted"
    LocationState.ProviderOff -> "Location: turned off in system settings"
    LocationState.Waiting -> "Location: waiting for a fix…"
    is LocationState.Available -> buildString {
        append("Radius centre (your position): ")
        append(String.format(Locale.US, "%.5f, %.5f", state.latitude, state.longitude))
        state.accuracyMeters?.let { append(String.format(Locale.US, " ±%.0f m", it)) }
    }
}

@Composable
fun ControlBar(
    startLabel: String,
    status: DetectionStatus,
    cameraActive: Boolean,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit,
    onReset: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (!cameraActive) {
            Button(onClick = onStart, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(startLabel)
            }
        } else {
            if (status == DetectionStatus.PAUSED) {
                Button(onClick = onResume, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Resume")
                }
            } else {
                FilledTonalButton(onClick = onPause, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Pause, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Pause")
                }
            }
            Button(
                onClick = onStop,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = ErrorRed, contentColor = Color.Black),
            ) {
                Icon(Icons.Filled.Stop, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Stop")
            }
        }
        OutlinedButton(onClick = onReset) {
            Icon(Icons.Filled.Refresh, contentDescription = "Reset counts")
        }
    }
}

@Composable
fun CenteredMessage(title: String, body: String?, modifier: Modifier = Modifier) {
    Column(modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center, color = Color.White)
        if (body != null) {
            Spacer(Modifier.size(8.dp))
            Text(body, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
                color = Color(0xFFCBD5E1))
        }
    }
}

/** Shown in the camera area while the camera is closed. */
@Composable
fun CameraPreviewPlaceholder(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier.padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content,
    )
}
