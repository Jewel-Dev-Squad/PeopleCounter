"""Prints every detection with its COCO label (score >= 0.4) for both models.
Usage: python3 tools/verify_labels.py <model_a.tflite> <model_b.tflite> photo1.jpg [photo2.jpg ...]"""
import sys, numpy as np
from PIL import Image
from ai_edge_litert.interpreter import Interpreter
import os
L=[l.strip() for l in open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'coco_labels.txt'))]
for m in sys.argv[1:3]:
    it=Interpreter(model_path=m); it.allocate_tensors(); d=it.get_input_details()[0]; h,w=d['shape'][1:3]
    for p in sys.argv[3:]:
        im=Image.open(p).convert('RGB'); it.set_tensor(d['index'],np.expand_dims(np.asarray(im.resize((w,h))),0)); it.invoke()
        b,c,s,n=[it.get_tensor(o['index']) for o in it.get_output_details()]
        print(m.split('/')[-1][:8], p.split('/')[-1], [(int(ci), L[int(ci)], round(float(si),2)) for ci,si in zip(c[0],s[0]) if si>=0.4])
