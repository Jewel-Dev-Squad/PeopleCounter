#!/usr/bin/env bash
# Compiles the Android-independent core (detection decoding, tracking, counting,
# coverage, overlay maths, throttling) with plain kotlinc and runs its JUnit
# tests WITHOUT the Android SDK. Useful on CI machines without Android tooling.
# Usage: KOTLINC=/path/to/kotlinc JUNIT_CP=junit-4.13.2.jar:hamcrest-core-1.3.jar tools/run_core_tests.sh
# The normal way to run the same tests is:  ./gradlew testDebugUnitTest
set -euo pipefail
cd "$(dirname "$0")/../app/src"
KOTLINC=${KOTLINC:-kotlinc}
: "${JUNIT_CP:?set JUNIT_CP to junit-4.13.2.jar:hamcrest-core-1.3.jar}"
OUT=$(mktemp -d)
M=main/java/com/hibee/peoplecounter
"$KOTLINC" -jvm-target 17 -cp "$JUNIT_CP" -d "$OUT" \
  $M/detection/DetectionResult.kt $M/detection/CocoLabels.kt $M/detection/DetectionDecoder.kt $M/detection/ModelOption.kt \
  $M/tracking/ObjectTracker.kt $M/counting/LineCrossingCounter.kt $M/counting/PeopleCountingEngine.kt \
  $M/coverage/Coverage.kt $M/camera/PerformanceMonitor.kt $M/ui/components/OverlayTransform.kt \
  $M/settings/AppSettings.kt $(find test -name '*.kt')
STDLIB=$(dirname "$(readlink -f "$(command -v "$KOTLINC")")")/../lib/kotlin-stdlib.jar
java -cp "$OUT:$JUNIT_CP:$STDLIB" org.junit.runner.JUnitCore \
  com.hibee.peoplecounter.detection.DetectionDecoderTest \
  com.hibee.peoplecounter.tracking.ObjectTrackerTest \
  com.hibee.peoplecounter.counting.PeopleCountingEngineTest \
  com.hibee.peoplecounter.counting.LineCrossingCounterTest \
  com.hibee.peoplecounter.MiscLogicTest \
  com.hibee.peoplecounter.detection.CocoLabelsTest
